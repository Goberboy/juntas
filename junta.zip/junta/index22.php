<!doctype html>
<html>
<head>

<meta charset="UTF-8">
<title>JUNTA</title>
<center><IMG SRC="images/banner.png"></center>
<center><IMG SRC="images/aplicacion.png"></center>


</head>
<body>
<div id="main">
	<div id="nav">
  
    <?php include("menu2.php"); ?>	
</div>
	<iframe id="content" src="inicio.php" allowtransparency="1" scrolling="auto" > No Soporta iFrames</iframe>
    <a href="salir.php"><strong>Salir</strong></a>
</div>
<footer align="center" id="pie" >
<b style="font-size: 13px;">GOBERNACIÓN DE BOYACÁ<br>
<span style="font-size: 13px;">Calle 20 No. 9 - 90 Casa de la Torre Tunja - Boyacá</span>
<br><span style="font-size: 13px;">Horario de Atención: Lunes a Viernes, 8:00 a.m. a 12:00 m - 2:00 p.m. a 6:00 p.m.</span>
<br><span style="font-size: 13px;">PBX+ (57) 8742 0150 / 8742 0222</span>
<br><span style="font-size: 13px;">NIT Gobernación de Boyacá: 891 800 498-1 --- Código DANE: 15</span>

<br><a href="http://boyaca.gov.co/gobernacion/politicas-de-privacidad-y-terminos-de-uso" target="_blank" style="font-size: 13px;">Politicas de Privacidad y Uso</a>
<br><span style="font-size: 13px;">Diseñada y Desarrollada por Dirección de Sistemas.</span>
</footer>
</body>
</html>