<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "1,2,3";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['usuariojunta'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['usuariojunta'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?><!doctype html>
<html>
<head>

<meta charset="UTF-8">
<title>JUNTA</title>
<center><IMG SRC="images/banner.png"></center>
<center><IMG SRC="images/aplicacion.png"></center>


</head>
<body>
<div id="main">
	<div id="nav">
   <?php 
		if ($_SESSION['MM_UserGroup'] == 1){include("menu.php");}
		if ($_SESSION['MM_UserGroup'] == 2){include("menu2.php");}
		if ($_SESSION['MM_UserGroup'] == 3){include("menu3.php");}
		 ?>
	
</div>
	<iframe id="content" src="inicio.php" allowtransparency="1" scrolling="auto" > No Soporta iFrames</iframe>
    <a href="salir.php"><strong>Salir</strong></a>
</div>
<footer align="center" id="pie" >
<b style="font-size: 13px;">GOBERNACIÓN DE BOYACÁ<br>
<span style="font-size: 13px;">Calle 20 No. 9 - 90 Casa de la Torre Tunja - Boyacá</span>
<br><span style="font-size: 13px;">Horario de Atención: Lunes a Viernes, 8:00 a.m. a 12:00 m - 2:00 p.m. a 6:00 p.m.</span>
<br><span style="font-size: 13px;">PBX+ (57) 8742 0150 / 8742 0222</span>
<br><span style="font-size: 13px;">NIT Gobernación de Boyacá: 891 800 498-1 --- Código DANE: 15</span>

<br><a href="http://boyaca.gov.co/gobernacion/politicas-de-privacidad-y-terminos-de-uso" target="_blank" style="font-size: 13px;">Politicas de Privacidad y Uso</a>
<br><span style="font-size: 13px;">Diseñada y Desarrollada por Dirección de Sistemas.</span>
</footer>
</body>
</html>