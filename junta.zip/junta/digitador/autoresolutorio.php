<?php
session_start();
//Connect to database
require_once('../Connections/junta.php');
$idjunta = $_SESSION['idjunta'];
//$idjunta = 9;
$fechaactual = date("Y/m/d");
$hora = date("H:i:s");
if (isset($_GET['cuenta'])) {
	 $factura1 = $_GET['cuenta'];
	}
	else {
		$factura1 = "";
		}
$autoincremental = $factura1;		
//datos de la junta 
$consultajunta=mysql_query("SELECT * FROM junta WHERE Id_Junta = '$idjunta'");
$consultajunta1 = mysql_fetch_array($consultajunta);
$razon = 				$consultajunta1['Razon'];
$fechacreacion = 		$consultajunta1['F_Creacion'];
$personeriajuridica = 	$consultajunta1['N_Personeria_Juridica'];
$idmunicipio = 			$consultajunta1['Id_Municipio'];
$idtipojunta = 			$consultajunta1['Id_Tipo_Junta'];
$idinstitucion = 		$consultajunta1['Id_Institucion'];
$idreconocida = 		$consultajunta1['Id_Reconocida'];
// datos del municipio de la junta 
$consultamunicipio=mysql_query("SELECT * FROM municipio WHERE Id_Municipio = '$idmunicipio'");
$consultamunicipio1 = mysql_fetch_array($consultamunicipio);
$municipio = 			$consultamunicipio1['Municipio'];
//datos del tipo de junta de la junta
$consultatipojunta=mysql_query("SELECT * FROM tipo_junta WHERE Id_Tipo_Junta = '$idtipojunta'");
$consultatipojunta1 = mysql_fetch_array($consultatipojunta);
$tipojunta = 			$consultatipojunta1['T_Junta'];
//datos de la institucion de la junta
$consultainstitucion=mysql_query("SELECT * FROM institucion WHERE Id_Institucion = '$idinstitucion'");
$consultainstitucion1 = mysql_fetch_array($consultainstitucion);
$institucion = 			$consultainstitucion1['Nom_Institucion'];
//datos de la reconocida de la junta
$consultareconocida=mysql_query("SELECT * FROM reconocida WHERE Id_Reconocida = '$idreconocida'");
$consultareconocida1 = mysql_fetch_array($consultareconocida);
$reconocida = 			$consultareconocida1['Reconocida'];
//datos de la ultima asamblea de la junta
$consultaasamblea=mysql_query("SELECT * FROM asamblea WHERE Id_junta = '$idjunta' ORDER BY Id_Asamblea DESC LIMIT 1");
$consultaasamblea1 = mysql_fetch_array($consultaasamblea);
$fechaasamblea = 		$consultaasamblea1['F_Asamblea'];
$fechainicioperiodo = 	$consultaasamblea1['F_I_Periodo'];
$fechafinperiodo = 		$consultaasamblea1['F_F_Periodo'];

// datos mandatario
$mandatario1 =mysql_query("SELECT * FROM mandatario ORDER BY Id_Mandatario DESC LIMIT 1");
$mandatario = mysql_fetch_array($mandatario1);
$nombre_mandatario = 			$mandatario['Nombre_Mandatario'];
$cargo_mandatario= 				$mandatario['Cargo_Mandatario'];
$firmamandatario = 				$mandatario['Imagen'];

require('../necesarios/fpdf.php');
class PDF extends FPDF
{
var $B;
var $I;
var $U;
var $HREF;

function PDF($orientation='P', $unit='mm', $size='Legal')
{
    // Llama al constructor de la clase padre
    $this->FPDF($orientation,$unit,$size);
    // Iniciación de variables
    $this->B = 0;
    $this->I = 0;
    $this->U = 0;
    $this->HREF = '';
}

function WriteHTML($html)
{
    // Intérprete de HTML
    $html = str_replace("\n",' ',$html);
    $a = preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
    foreach($a as $i=>$e)
    {
        if($i%2==0)
        {
            // Text
            if($this->HREF)
                $this->PutLink($this->HREF,$e);
            else
                $this->Write(5,$e);
        }
        else
        {
            // Etiqueta
            if($e[0]=='/')
                $this->CloseTag(strtoupper(substr($e,1)));
            else
            {
                // Extraer atributos
                $a2 = explode(' ',$e);
                $tag = strtoupper(array_shift($a2));
                $attr = array();
                foreach($a2 as $v)
                {
                    if(preg_match('/([^=]*)=["\']?([^"\']*)/',$v,$a3))
                        $attr[strtoupper($a3[1])] = $a3[2];
                }
                $this->OpenTag($tag,$attr);
            }
        }
    }
}

function OpenTag($tag, $attr)
{
    // Etiqueta de apertura
    if($tag=='B' || $tag=='I' || $tag=='U')
        $this->SetStyle($tag,true);
    if($tag=='A')
        $this->HREF = $attr['HREF'];
    if($tag=='BR')
        $this->Ln(5);
}

function CloseTag($tag)
{
    // Etiqueta de cierre
    if($tag=='B' || $tag=='I' || $tag=='U')
        $this->SetStyle($tag,false);
    if($tag=='A')
        $this->HREF = '';
}

function SetStyle($tag, $enable)
{
    // Modificar estilo y escoger la fuente correspondiente
    $this->$tag += ($enable ? 1 : -1);
    $style = '';
    foreach(array('B', 'I', 'U') as $s)
    {
        if($this->$s>0)
            $style .= $s;
    }
    $this->SetFont('',$style);
}

function PutLink($URL, $txt)
{
    // Escribir un hiper-enlace
    $this->SetTextColor(0,0,255);
    $this->SetStyle('U',true);
    $this->Write(5,$txt,$URL);
    $this->SetStyle('U',false);
    $this->SetTextColor(0);
}}
$mensaje1 = "En  uso  de  sus facultades legales  y en especial las que le confiere la ley 52 de 1990, la ley 743 de junio de 2002, Decretos 2350 del 20 de agosto de 2003 y 890 de 2008, compilados en el Decreto 1066 del 2015  y  Decretos  Departamentales  1237 y 1238 del 1 de agosto  de 2006.";
$mensaje2 = "Que la $tipojunta $razon del Municipio de $municipio, Departamento de Boyacá, con $reconocida No.$personeriajuridica de fecha $fechacreacion, expedida por $institucion, Realizó asamblea general el dia $fechaasamblea con el fin de elegir dignatarios para el periodo comprendido entre el $fechainicioperiodo y el $fechafinperiodo. Que estudiada la documentación, se encontró que la elección y solicitud se hicieron y presentaron oportunamente de acuerdo a los requisitos legales vigentes.";
if($tipojunta=="Asociacion Comunal de Juntas")
{
 $mensaje3 = "ARTICULO PRIMERO: Inscribir a la $razon del municipio de $municipio,Departamento de Boyacá, para el periodo comprendido entre el $fechainicioperiodo y el $fechafinperiodo a los siguientes dignatarios:";
 }
 else
 {
 $mensaje3 = "ARTICULO PRIMERO: Inscribir a la $tipojunta $razon del municipio de $municipio,Departamento de Boyacá, para el periodo comprendido entre el $fechainicioperiodo y el $fechafinperiodo a los siguientes dignatarios:";
 }
//directivos
$consulta1="SELECT * FROM persona, detalle_persona, cargo, comision WHERE detalle_persona.Id_Junta = '$idjunta' AND detalle_persona.Documento = persona.Documento AND detalle_persona.Id_Cargo = cargo.Id_Cargo AND detalle_persona.Id_Comision = comision.Id_Comision AND (detalle_persona.Estado = 'Activo' OR detalle_persona.Estado = 'Cambio') AND detalle_persona.Id_Cargo in (1,2,3,4,12,13) ORDER BY detalle_persona.Id_Cargo ASC";
$r1=mysql_query($consulta1);
$i1=mysql_num_rows($r1);

//Secretario General
$consulta6="SELECT * FROM persona, detalle_persona, cargo, comision WHERE detalle_persona.Id_Junta = '$idjunta' AND detalle_persona.Documento = persona.Documento AND detalle_persona.Id_Cargo = cargo.Id_Cargo AND detalle_persona.Id_Comision = comision.Id_Comision AND (detalle_persona.Estado = 'Activo' OR detalle_persona.Estado = 'Cambio') AND detalle_persona.Id_Cargo in (14) ORDER BY detalle_persona.Id_Cargo ASC";
$r6=mysql_query($consulta6);
$i6=mysql_num_rows($r6);

//fiscalia
$consulta2="SELECT * FROM persona, detalle_persona, cargo, comision WHERE detalle_persona.Id_Junta = '$idjunta' AND detalle_persona.Documento = persona.Documento AND detalle_persona.Id_Cargo = cargo.Id_Cargo AND detalle_persona.Id_Comision = comision.Id_Comision AND detalle_persona.Estado = 'Activo' AND detalle_persona.Id_Cargo in (5,6) ORDER BY detalle_persona.Id_Cargo ASC";
$r2=mysql_query($consulta2);
$i2=mysql_num_rows($r2);
//comision de convivencia y conciliacion
$consulta3="SELECT * FROM persona, detalle_persona, cargo, comision WHERE detalle_persona.Id_Junta = '$idjunta' AND detalle_persona.Documento = persona.Documento AND detalle_persona.Id_Cargo = cargo.Id_Cargo AND detalle_persona.Id_Comision = comision.Id_Comision AND detalle_persona.Estado = 'Activo' AND detalle_persona.Id_Cargo in (7) ORDER BY detalle_persona.Id_Cargo ASC";
$r3=mysql_query($consulta3);
$i3=mysql_num_rows($r3);
//comisiones de trabajo
$consulta4="SELECT * FROM persona, detalle_persona, cargo, comision WHERE detalle_persona.Id_Junta = '$idjunta' AND detalle_persona.Documento = persona.Documento AND detalle_persona.Id_Cargo = cargo.Id_Cargo AND detalle_persona.Id_Comision = comision.Id_Comision AND detalle_persona.Estado = 'Activo' AND (detalle_persona.Id_Cargo in (8) OR detalle_persona.Id_Cargo2 in (8)) ORDER BY detalle_persona.Id_Cargo ASC";
$r4=mysql_query($consulta4);
$i4=mysql_num_rows($r4);
//delegados
$consulta5="SELECT * FROM persona, detalle_persona, cargo, comision WHERE detalle_persona.Id_Junta = '$idjunta' AND detalle_persona.Documento = persona.Documento AND detalle_persona.Id_Cargo = cargo.Id_Cargo AND detalle_persona.Id_Comision = comision.Id_Comision AND (detalle_persona.Estado = 'Activo' OR detalle_persona.Estado = 'Cambio') AND (detalle_persona.Id_Cargo in (9) OR detalle_persona.Id_Cargo2 in (9)) ORDER BY detalle_persona.Id_Cargo ASC";
$r5=mysql_query($consulta5);
$i5=mysql_num_rows($r5);

//Secretarías ejecutivas
$consulta7="SELECT * FROM persona, detalle_persona, cargo, comision WHERE detalle_persona.Id_Junta = '$idjunta' AND detalle_persona.Documento = persona.Documento AND detalle_persona.Id_Cargo = cargo.Id_Cargo AND detalle_persona.Id_Comision = comision.Id_Comision AND (detalle_persona.Estado = 'Activo' OR detalle_persona.Estado = 'Cambio') AND detalle_persona.Id_Cargo in (17,18,19,20,21,22) ORDER BY detalle_persona.Id_Cargo ASC";
$r7=mysql_query($consulta7);
$i7=mysql_num_rows($r7);

//Comisiones Empresariales ASO
$consulta8="SELECT * FROM persona, detalle_persona, cargo, comision WHERE detalle_persona.Id_Junta = '$idjunta' AND detalle_persona.Documento = persona.Documento AND detalle_persona.Id_Cargo = cargo.Id_Cargo AND detalle_persona.Id_Comision = comision.Id_Comision AND (detalle_persona.Estado = 'Activo' OR detalle_persona.Estado = 'Cambio') AND detalle_persona.Id_Cargo in (23) ORDER BY detalle_persona.Id_Cargo ASC";
$r8=mysql_query($consulta8);
$i8=mysql_num_rows($r8);


$j = 'J';
	$pdf=new PDF();
	$pdf->AddPage();
	$pdf->SetFont('Arial','B',10);
	$pdf->Image("../necesarios/inicio.png", 10 ,10 ,45 ,20 );
		$pdf->Ln(12);
	$pdf->Cell (0,0,  "SECRETARÍA DE PARTICIPACIÓN Y DEMOCRACIA",0,1,'C');
		$pdf->Ln(4);
	$pdf->Cell (0,0,  "DIRECCIÓN DE PARTICIPACIÓN Y ADMINISTRACIÓN LOCAL",0,0,'C');
		$pdf->Ln(3);
	$pdf->Cell (0,0,  "No.AUTO: $autoincremental",0,0,'L');
		$pdf->Ln(2);
	$pdf->Cell (0,0,  "EL DIRECTOR DE PARTICIPACIÓN Y ADMINISTRACIÓN LOCAL",0,0,'C');
	$pdf->SetFont('Arial','',10);	
		$pdf->Ln(3);
	$pdf->MultiCell(190, 4, utf8_decode($mensaje1) , 0,$j);
			$pdf->Ln(3);
	$pdf->SetFont('Arial','B',10);	
	$pdf->Cell (0,0,  "CONSIDERANDO:",0,0,'C');
			$pdf->Ln(3);
	$pdf->SetFont('Arial','',10);		
	$pdf->MultiCell(190, 4, utf8_decode($mensaje2) , 0,$j);
			$pdf->Ln(3);
	$pdf->SetFont('Arial','B',10);
	$pdf->Cell (0,0,  "RESUELVE:",0,0,'C');
			$pdf->Ln(3);
	$pdf->SetFont('Arial','',10);
	$pdf->MultiCell(190, 4, utf8_decode($mensaje3) , 0,$j);	
			$pdf->Ln(3);
	$pdf->SetFont('Arial','B',9);
	$pdf->Cell (0,0,  utf8_decode($tipojunta),0,0,'C');
//DIRECTIVOS
if ($i1>0){
		$pdf->Ln(4);
	$pdf->Cell (0,0,  "DIRECTIVOS",0,0,'C');
		$pdf->Ln(4);
	$pdf->Cell(35,7,"CARGO",1,0,'C');
	$pdf->Cell(90,7,"NOMBRE Y APELLIDO ",1,0,'C');
	//$pdf->Cell(50,7,'APELLIDO',1,0,'C');
	$pdf->Cell(30,7,'DOCUMENTO',1,0,'C');
	$pdf->Cell(35,7,'EXPEDIDO EN',1,0,'C');	
		$pdf->Ln();
while($registro1=mysql_fetch_row($r1)){
	$pdf->SetFont('Arial','',8);
	$pdf->Cell(35,7,utf8_decode($registro1[30]),1,0,'L');
	$pdf->Cell(90,7,"$registro1[3] $registro1[4]",1,0,'L');
	//$pdf->Cell(50,7,utf8_decode($registro1[1]),1,0,'C');
	if($registro1[0]=="99081912331"){
	 $pdf->Cell(30,7,utf8_decode(number_format($registro1[0],0,'','')),1,0,'C');
	}else{
	$pdf->Cell(30,7,utf8_decode(number_format($registro1[0],0,'','')),1,0,'C');
	}
	$pdf->Cell(35,7,utf8_decode($registro1[2]),1,0,'C');
		$pdf->Ln();
	}	
}
//SECRETARIO GENERAL
if ($i6>0){
		$pdf->Ln(4);
	$pdf->Cell (0,0,  "SECRETARIO(A) GENERAL",0,0,'C');
		$pdf->Ln(4);
	$pdf->Cell(35,7,"CARGO",1,0,'C');
	$pdf->Cell(90,7,"NOMBRE Y APELLIDO ",1,0,'C');
	//$pdf->Cell(50,7,'APELLIDO',1,0,'C');
	$pdf->Cell(30,7,'DOCUMENTO',1,0,'C');
	$pdf->Cell(35,7,'EXPEDIDO EN',1,0,'C');	
		$pdf->Ln();
while($registro6=mysql_fetch_row($r6)){
	$pdf->SetFont('Arial','',8);
	$pdf->Cell(35,7,utf8_decode($registro6[30]),1,0,'L');
	$pdf->Cell(90,7,"$registro6[3] $registro6[4]",1,0,'L');
	//$pdf->Cell(50,7,utf8_decode($registro6[1]),1,0,'C');
	$pdf->Cell(30,7,utf8_decode(number_format($registro6[0],0,'','')),1,0,'C');
	$pdf->Cell(35,7,utf8_decode($registro6[2]),1,0,'C');
		$pdf->Ln();
	}	
}

//FISCALES
if ($i2>0){
		$pdf->Ln(4);
	$pdf->SetFont('Arial','B',9);
	$pdf->Cell (0,0,  "FISCAL",0,0,'C');
		$pdf->Ln(4);
	$pdf->Cell(35,7,"CARGO",1,0,'C');
	$pdf->Cell(90,7,"NOMBRE Y APELLIDO ",1,0,'C');
	$pdf->Cell(30,7,'DOCUMENTO',1,0,'C');
	$pdf->Cell(35,7,'EXPEDIDO EN',1,0,'C');	
		$pdf->Ln();
while($registro2=mysql_fetch_row($r2)){
	$pdf->SetFont('Arial','',8);
	$pdf->Cell(35,7,utf8_decode($registro2[30]),1,0,'L');
	$pdf->Cell(90,7,"$registro2[3] $registro2[4]",1,0,'L');
	$pdf->Cell(30,7,utf8_decode(number_format($registro2[0],0,'','')),1,0,'C');
	$pdf->Cell(35,7,utf8_decode($registro2[2]),1,0,'C');
		$pdf->Ln();
	}	
}
//COMISION DE CONVIVENCIA Y CONCILIACION
if ($i3>0){
		$pdf->Ln(4);
	$pdf->SetFont('Arial','B',9);
	$pdf->Cell (0,0,  "COMISIÓN DE CONVIVENCIA Y CONCILIACIÓN",0,0,'C');
		$pdf->Ln(4);
	$pdf->Cell(35,7,"CARGO",1,0,'C');
	$pdf->Cell(90,7,"NOMBRE Y APELLIDO ",1,0,'C');
	$pdf->Cell(30,7,'DOCUMENTO',1,0,'C');
	$pdf->Cell(35,7,'EXPEDIDO EN',1,0,'C');	
		$pdf->Ln();
while($registro3=mysql_fetch_row($r3)){
	$pdf->SetFont('Arial','',8);
	$pdf->Cell(35,7,utf8_decode($registro3[30]),1,0,'L');
	$pdf->Cell(90,7,"$registro3[3] $registro3[4]",1,0,'L');
	$pdf->Cell(30,7,utf8_decode(number_format($registro3[0],0,'','')),1,0,'C');
	$pdf->Cell(35,7,utf8_decode($registro3[2]),1,0,'C');
		$pdf->Ln();
	}	
}
//COMISION DE TRABAJO
if ($i4>0){
		$pdf->Ln(4);
	$pdf->SetFont('Arial','B',9);
	$pdf->Cell (0,0,  "COMISIÓN DE TRABAJO",0,0,'C');
		$pdf->Ln(4);
	$pdf->Cell(35,7,"COMISIÓN",1,0,'C');
	$pdf->Cell(90,7,"NOMBRE Y APELLIDO ",1,0,'C');
	$pdf->Cell(30,7,'DOCUMENTO',1,0,'C');
	$pdf->Cell(35,7,'EXPEDIDO EN',1,0,'C');	
		$pdf->Ln();
while($registro4=mysql_fetch_row($r4)){
	$pdf->SetFont('Arial','',8);
	$pdf->Cell(35,7,$registro4[32],1,0,'L');
	$pdf->Cell(90,7,"$registro4[3] $registro4[4]",1,0,'L');
	$pdf->Cell(30,7,utf8_decode(number_format($registro4[0],0,'','')),1,0,'C');
	$pdf->Cell(35,7,utf8_decode($registro4[2]),1,0,'C');
		$pdf->Ln();
	}	
}
//DELEGADOS ANTE LA ORGANIZACIÒN SUPERIOR
if ($i5>0){
		$pdf->Ln(4);
	$pdf->SetFont('Arial','B',9);
	$pdf->Cell (0,0,  "DELEGADOS ANTE LA ORGANIZACION DE GRADO SUPERIOR",0,0,'C');
		$pdf->Ln(4);
	$pdf->Cell(35,7,"CARGO",1,0,'C');
	$pdf->Cell(90,7,"NOMBRE Y APELLIDO ",1,0,'C');
	$pdf->Cell(30,7,'DOCUMENTO',1,0,'C');
	$pdf->Cell(35,7,'EXPEDIDO EN',1,0,'C');	
		$pdf->Ln();
while($registro5=mysql_fetch_row($r5)){
	$pdf->SetFont('Arial','',8);
		if ($registro5[17]== 9){
	$pdf->Cell(35,7,utf8_decode("Delegado"),1,0,'L');}
	else{
	$pdf->Cell(35,7,utf8_decode($registro5[30]),1,0,'L');}
	$pdf->Cell(90,7,"$registro5[3] $registro5[4]",1,0,'L');
	$pdf->Cell(30,7,utf8_decode(number_format($registro5[0],0,'','')),1,0,'C');
	$pdf->Cell(35,7,utf8_decode($registro5[2]),1,0,'C');
		$pdf->Ln();
	}	
}

//SECRETARIAS EJECUTIVAS
if ($i7>0){
		$pdf->Ln(4);
	$pdf->SetFont('Arial','B',9);
	$pdf->Cell (0,0,  "SECRETARIAS EJECUTIVAS",0,0,'C');
		$pdf->Ln(4);
	$pdf->Cell(35,7,"SECRETARIA",1,0,'C');
	$pdf->Cell(90,7,"NOMBRE Y APELLIDO ",1,0,'C');
	$pdf->Cell(30,7,'DOCUMENTO',1,0,'C');
	$pdf->Cell(35,7,'EXPEDIDO EN',1,0,'C');	
		$pdf->Ln();
while($registro7=mysql_fetch_row($r7)){
	$pdf->SetFont('Arial','',8);
	$pdf->Cell(35,7,$registro7[32],1,0,'L');
	$pdf->Cell(90,7,"$registro7[3] $registro7[4]",1,0,'L');
	$pdf->Cell(30,7,utf8_decode(number_format($registro7[0],0,'','')),1,0,'C');
	$pdf->Cell(35,7,utf8_decode($registro7[2]),1,0,'C');
		$pdf->Ln();
	}	
}

//COMISIONES EMPRESARIALES ASO
if ($i8>0){
		$pdf->Ln(4);
	$pdf->SetFont('Arial','B',9);
	$pdf->Cell (0,0,  "COMISIONES EMPRESARIALES",0,0,'C');
		$pdf->Ln(4);
	$pdf->Cell(35,7,"COMISIÓN",1,0,'C');
	$pdf->Cell(90,7,"NOMBRE Y APELLIDO ",1,0,'C');
	$pdf->Cell(30,7,'DOCUMENTO',1,0,'C');
	$pdf->Cell(35,7,'EXPEDIDO EN',1,0,'C');	
		$pdf->Ln();
while($registro8=mysql_fetch_row($r8)){
	$pdf->SetFont('Arial','',8);
	$pdf->Cell(35,7,$registro8[32],1,0,'L');
	$pdf->Cell(90,7,"$registro8[3] $registro8[4]",1,0,'L');
	$pdf->Cell(30,7,utf8_decode(number_format($registro8[0],0,'','')),1,0,'C');
	$pdf->Cell(35,7,utf8_decode($registro8[2]),1,0,'C');
		$pdf->Ln();
	}	
}

//articulo segundo
		$pdf->Ln(4);
	$pdf->SetFont('Arial','',10);
	$pdf->Cell(0,0, "ARTICULO SEGUNDO: El presente auto de reconocimiento rige a partir de la fecha de su expedición",0,0,'L');
//pie de pagina 
		$pdf->Ln(6);
	$pdf->Cell (0,0,  "COMUNÌQUESE Y CÙMPLASE",0,0,'C');
		$pdf->Ln(2);
	$pdf->Cell (0,0,"Dado el día: $fechaactual",0,0,'L');
		$pdf->Ln(1);			
	$pdf->Cell (0,0,$pdf->Image("../".$firmamandatario,87),0,0,'',false);
		$pdf -> Ln (-10);
	$pdf->SetFont('Arial','B',10);
	$pdf -> Cell (0,0,  $nombre_mandatario,0,0,'C');
		$pdf -> Ln (4);
	$pdf->SetFont('Arial','',10);
	$pdf -> Cell (0,0,  $cargo_mandatario,0,0,'C');
		$pdf -> Ln (3);
	$pdf->SetFont('Arial','',8);
	$pdf -> Cell (0,0,  "Elaborò:________________",0,0,'L');
		$pdf -> Ln (3);
	$pdf -> Cell (0,0,  "Revisò_________________",0,0,'L');
		$pdf -> Ln (3);
	$pdf -> Cell (0,0,  "",0,0,'L');
		$pdf -> Ln (3);
	$pdf -> Cell (0,0,  "",0,0,'L');
		$pdf -> Ln (3);
	$pdf -> Cell (0,0,  "GOBERNACIÓN DE BOYACÁ",0,0,'L');
$pdf->Output();	
//unset($_SESSION['cuenta']); 
exit;

?>

