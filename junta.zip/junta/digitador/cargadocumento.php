<?php
require_once '../Connections/junta.php';
session_start();
$archivo = "consecutivo.txt";
$abrir = fopen($archivo,"r");
$cuenta = trim(fread($abrir,filesize($archivo))); 
if ($cuenta != "") ++$cuenta;
 else $cuenta = 1;
 @fclose($abrir);
 $abrir = fopen($archivo,"w");
 @fputs($abrir,$cuenta);
 @fclose($abrir); 
//echo 'Esta es la visita: '.$cuenta;
 $factura=$cuenta; 
$tamNumero = strlen($factura); 
if($tamNumero==1) 
  $factura1 = "000$factura";
   elseif ($tamNumero==2) 
  $factura1 = "00$factura"; 
elseif ($tamNumero == 3) 
   $factura1 = "0$factura";
$consecutivo =  $factura1;   

$numero=$_REQUEST["Numero"];
$fecha = date("Y/m/d");
$idusuario = $_SESSION['usuariojunta'];
$idjunta = $_SESSION['idjunta'];
$nombrecompleto = $_FILES['documentoauto']['name'];
$ruta=$_FILES["documentoauto"]["tmp_name"];
$nombre = explode(".", $nombrecompleto); 
$extension = end($nombre);
$destino1="../autoresolutorio/".$consecutivo.".".$extension;
$destino= $consecutivo.".".$extension;
copy($ruta,$destino1);
mysql_query("insert into autoresolutorio (Numero,Ruta,Id_Usuario,F_Ingreso,Id_Junta) values('$numero','$destino','$idusuario','$fecha','$idjunta')");
header("Location: subir.php");
?>
