<?php require_once('../Connections/junta.php'); ?>
<script type="text/javascript">
/*alerta de que un documento se encuenta tregistrado en un periodo menor a 3 meses*/
function RegistroRepetido() {
alert('<?php echo  "USUARIO INGRESADO CORRECTAMENTE";?>');
document.location=('datosjunta.php');
}
function Registroerror() {
alert('<?php echo  "USUARIO NO INGRESADO";?>');
document.location=('datosjunta.php');
}
</script>
<?php
session_start();
$_SESSION['idjunta'];
$_SESSION['usuariojunta'];
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}


if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO persona (Documento, Tipo_Documento, Expedido, Nombre_P, Apellido, Genero, Edad, F_Nacimiento, Residencia, Telefono, Profesion, Email) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Documento'], "text"),
                       GetSQLValueString($_POST['Tipo_Documento'], "text"),
                       GetSQLValueString($_POST['Expedido'], "text"),
                       GetSQLValueString($_POST['Nombre_P'], "text"),
                       GetSQLValueString($_POST['Apellido'], "text"),
                       GetSQLValueString($_POST['Genero'], "text"),
                       GetSQLValueString($_POST['Edad'], "int"),
                       GetSQLValueString($_POST['F_Nacimiento'], "text"),
                       GetSQLValueString($_POST['Residencia'], "text"),
                       GetSQLValueString($_POST['Telefono'], "text"),
                       GetSQLValueString($_POST['Profesion'], "text"),
                       GetSQLValueString($_POST['Email'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result1 = mysql_query($insertSQL, $junta) or die(mysql_error());
$documento = $_POST['Documento'];
$insertSQL1 = sprintf("INSERT INTO grupo (Documento, Indigena, Afro, Con_Disca, Desplazado, Madre_Gest, Madre_Lact, Cabeza_Hogar, Adul_Mayor, LGBTI, Otra) VALUES ('$documento', %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",

                       GetSQLValueString($_POST['Indigena'], "text"),
                       GetSQLValueString($_POST['Afro'], "text"),
                       GetSQLValueString($_POST['Con_Disca'], "text"),
                       GetSQLValueString($_POST['Desplazado'], "text"),
                       GetSQLValueString($_POST['Madre_Gest'], "text"),
                       GetSQLValueString($_POST['Madre_Lact'], "text"),
                       GetSQLValueString($_POST['Cabeza_Hogar'], "text"),
                       GetSQLValueString($_POST['Adul_Mayor'], "text"),
                       GetSQLValueString($_POST['LGBTI'], "text"),
                       GetSQLValueString($_POST['Otra'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result2 = mysql_query($insertSQL1, $junta) or die(mysql_error());
// datos para tabla detalle persona 
if ($_POST['Id_Cargo'] == 4){$password = $documento; $tipousuario = 3; $estado = "Cambio";}else { $password = "consulta";$tipousuario = 4; $estado = "Activo"; }


$insertSQL3 = sprintf("INSERT INTO detalle_persona (Documento, N_Afiliacion, F_Afiliacion, Id_Cargo, Id_Junta, Id_Periodo, Id_Comision, Sub_Direccion, Estado, Password, Id_Tipo_Usuario, Id_Usuario, F_Creacion, H_Creacion, Ip_Creacion) VALUES ('$documento', %s, %s, %s, %s, %s, %s, %s, '$estado', SHA('$password'), '$tipousuario', %s, %s, %s, %s)",
                       
                       GetSQLValueString($_POST['N_Afiliacion'], "int"),
                       GetSQLValueString($_POST['F_Afiliacion'], "text"),
                       GetSQLValueString($_POST['Id_Cargo'], "int"),
                       GetSQLValueString($_POST['Id_Junta'], "int"),
                       GetSQLValueString($_POST['Id_Periodo'], "int"),
                       GetSQLValueString($_POST['Id_Comision'], "int"),
                       GetSQLValueString($_POST['Sub_Direccion'], "text"),
                       GetSQLValueString($_POST['Id_Usuario'], "text"),
                       GetSQLValueString($_POST['F_Creacion'], "text"),
                       GetSQLValueString($_POST['H_Creacion'], "text"),
                       GetSQLValueString($_POST['Ip_Creacion'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result3 = mysql_query($insertSQL3, $junta) or die(mysql_error());

echo "<script type='text/javascript'>RegistroRepetido();</script>";

}

mysql_select_db($database_junta, $junta);
$query_cargo = "SELECT * FROM cargo ORDER BY Id_Cargo ASC";
$cargo = mysql_query($query_cargo, $junta) or die(mysql_error());
$row_cargo = mysql_fetch_assoc($cargo);
$totalRows_cargo = mysql_num_rows($cargo);

mysql_select_db($database_junta, $junta);
$query_comision = "SELECT * FROM comision ORDER BY Nombre_C ASC";
$comision = mysql_query($query_comision, $junta) or die(mysql_error());
$row_comision = mysql_fetch_assoc($comision);
$totalRows_comision = mysql_num_rows($comision);

mysql_select_db($database_junta, $junta);
$query_periodo = "SELECT * FROM periodo ORDER BY periodo.Id_Periodo DESC";
$periodo = mysql_query($query_periodo, $junta) or die(mysql_error());
$row_periodo = mysql_fetch_assoc($periodo);
$totalRows_periodo = mysql_num_rows($periodo);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../necesarios/tcal.css" />
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../necesarios/tcal.js"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>

<title>Documento sin título</title>
</head>

<body>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td colspan="2" align="center" nowrap="nowrap">Datos Personales</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Documento:</td>
      <td><input name="Documento" type="text" value="<?php echo $_SESSION["documento"]?>" size="32" readonly="readonly" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Tipo Documento:</td>
      <td><select name="Tipo_Documento">
        <option value="C.C">C.C</option>
        <option value="T.I">T.I</option>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Expedido:</td>
      <td><input type="text" name="Expedido" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Nombre:</td>
      <td><span id="sprytextfield1">
        <input type="text" name="Nombre_P" value="" size="32" />
      <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Apellido:</td>
      <td><span id="sprytextfield2">
        <input type="text" name="Apellido" value="" size="32" />
      <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Genero:</td>
      <td><span id="spryselect1">
        <select name="Genero">
          <option value="0">Seleccione...</option>
          <option value="F">Femenino</option>
          <option value="M">Masculino</option>
        </select>
      <span class="selectInvalidMsg">Seleccione un elemento válido.</span><span class="selectRequiredMsg">Seleccione un elemento.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Edad:</td>
      <td><input type="text" name="Edad" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">F Nacimiento:</td>
      <td><span id="sprytextfield4">
      <input type="text" name="F_Nacimiento" value="" size="28" class="tcal" />
<span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Residencia:</td>
      <td><input type="text" name="Residencia" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Telefono:</td>
      <td><input type="text" name="Telefono" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Profesion:</td>
      <td><input type="text" name="Profesion" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Email:</td>
      <td><span id="sprytextfield3">
      <input type="text" name="Email" value="" size="32" />
<span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
    </tr>

    <tr valign="baseline">
      <td colspan="2" align="center" nowrap="nowrap">Grupo Poblacional</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Indigena:</td>
      <td><select name="Indigena">
<option value="No" >No</option>
        <option value="Si" >Si</option
      ></select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Afro:</td>
      <td><select name="Afro">
<option value="No" >No</option>
        <option value="Si" >Si</option
      ></select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Con_Disca:</td>
      <td><select name="Con_Disca">
<option value="No" >No</option>
        <option value="Si" >Si</option
      ></select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Desplazado:</td>
      <td><select name="Desplazado">
<option value="No" >No</option>
        <option value="Si" >Si</option
      ></select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Madre_Gest:</td>
      <td><select name="Madre_Gest">
<option value="No" >No</option>
        <option value="Si" >Si</option
      ></select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Madre_Lact:</td>
      <td><select name="Madre_Lact">
<option value="No" >No</option>
        <option value="Si" >Si</option
      ></select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Cabeza_Hogar:</td>
      <td><select name="Cabeza_Hogar">
<option value="No" >No</option>
        <option value="Si" >Si</option
      ></select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Adul_Mayor:</td>
      <td><select name="Adul_Mayor">
<option value="No" >No</option>
        <option value="Si" >Si</option>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">LGBTI:</td>
      <td><select name="LGBTI">
<option value="No" >No</option>
        <option value="Si" >Si</option
      ></select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Otra:</td>
      <td><select name="Otra">
<option value="No" >No</option>
        <option value="Si" >Si</option>
      </select></td>
    </tr>

    <tr valign="baseline">
      <td colspan="2" align="center" nowrap="nowrap">Datos Junta</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Num.Afiliación:</td>
      <td><input type="text" name="N_Afiliacion" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">F Afiliación:</td>
      <td><span id="sprytextfield5">
      <input type="text" name="F_Afiliacion" value="" size="28" class="tcal" />
<span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Periodo</td>
      <td><label for="Id_Periodo"></label>
        <select name="Id_Periodo" id="Id_Periodo">
          <?php
do {  
?>
          <option value="<?php echo $row_periodo['Id_Periodo']?>"><?php echo $row_periodo['Periodo']?></option>
          <?php
} while ($row_periodo = mysql_fetch_assoc($periodo));
  $rows = mysql_num_rows($periodo);
  if($rows > 0) {
      mysql_data_seek($periodo, 0);
	  $row_periodo = mysql_fetch_assoc($periodo);
  }
?>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Cargo:</td>
      <td><span id="spryselect2">
        <select name="Id_Cargo">
          <option value="0" >Seleccione...</option>
          <?php
do {  
?>
          <option value="<?php echo $row_cargo['Id_Cargo']?>"><?php echo $row_cargo['Cargo']?></option>
          <?php
} while ($row_cargo = mysql_fetch_assoc($cargo));
  $rows = mysql_num_rows($cargo);
  if($rows > 0) {
      mysql_data_seek($cargo, 0);
	  $row_cargo = mysql_fetch_assoc($cargo);
  }
?>
        </select>
      <span class="selectInvalidMsg">Seleccione un elemento válido.</span><span class="selectRequiredMsg">Seleccione un elemento.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Comision:</td>
      <td><span id="spryselect3">
        <select name="Id_Comision">
          <option value="0" >Seleccione...</option>
          <?php
do {  
?>
          <option value="<?php echo $row_comision['Id_Comision']?>"><?php echo $row_comision['Nombre_C']?></option>
          <?php
} while ($row_comision = mysql_fetch_assoc($comision));
  $rows = mysql_num_rows($comision);
  if($rows > 0) {
      mysql_data_seek($comision, 0);
	  $row_comision = mysql_fetch_assoc($comision);
  }
?>
        </select>
      <span class="selectInvalidMsg">Seleccione un elemento válido.</span><span class="selectRequiredMsg">Seleccione un elemento.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Sub Dirección:</td>
      <td><input type="text" name="Sub_Direccion" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Insertar registro" /></td>
    </tr>
  </table>

  <input type="hidden" name="Id_Junta" value="<?php echo $_SESSION['idjunta'];?>" />

  <input type="hidden" name="Id_Usuario" value="<?php echo $_SESSION['usuariojunta'];?>" />
  <input type="hidden" name="F_Creacion" value="<?php echo date("Y-m-d");?>" />
  <input type="hidden" name="H_Creacion" value="<?php echo date("H:i:s");?>" />
  <input type="hidden" name="Ip_Creacion" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>" />
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "none", {validateOn:["change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "none", {validateOn:["change"]});
var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1", {validateOn:["change"], invalidValue:"0"});
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "email", {useCharacterMasking:true, validateOn:["change"], isRequired:false});
var spryselect2 = new Spry.Widget.ValidationSelect("spryselect2", {invalidValue:"0", validateOn:["change"]});
var spryselect3 = new Spry.Widget.ValidationSelect("spryselect3", {invalidValue:"0", validateOn:["change"]});
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "date", {format:"yyyy-mm-dd", useCharacterMasking:true, isRequired:false, validateOn:["change"]});
var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5", "date", {format:"yyyy-mm-dd", useCharacterMasking:true, isRequired:false, validateOn:["change"]});
</script>
</body>
</html>
<?php
mysql_free_result($cargo);

mysql_free_result($comision);

mysql_free_result($periodo);
?>
