<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<?php 
session_start();
 $archivo = "cuenta.txt";
 $abrir = fopen($archivo,"r");
 $cuenta = trim(fread($abrir,filesize($archivo))); 

if ($cuenta != "") ++$cuenta;
 else $cuenta = 1;
 @fclose($abrir);
 $abrir = fopen($archivo,"w");
 @fputs($abrir,$cuenta);
 
@fclose($abrir); 
//echo 'Esta es la visita: '.$cuenta;
 
$factura=$cuenta; 
$tamNumero = strlen($factura); 

if($tamNumero==1) 
  $factura1 = "000$factura";
   elseif ($tamNumero==2) 
  $factura1 = "00$factura"; 
elseif ($tamNumero == 3) 
  $factura1 = "0$factura";
else
  $factura1 = "$factura";
header("Location: autoresolutorio.php?cuenta=".$factura1);
?>
</body>
</html>