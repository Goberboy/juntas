<?php 
require_once('../Connections/junta.php'); 
session_start();
$id = $_POST['Documento'];
$_SESSION["documento"] = $id;
//consultar persona para verificar si existe en la base de datos
$persona =mysql_query("SELECT * FROM persona  WHERE Documento = '$id'");
$personadatos = mysql_fetch_array($persona);

echo " existe " ;
echo $existe = mysql_num_rows($persona);
if($existe == 0){ header("Location: crearpersona.php");}
else {
//consultar datos de persona detalles
$persona1 =mysql_query("SELECT * FROM detalle_persona  WHERE Documento = '$id' AND Estado = 'Activo' ORDER BY Id_Detalle_Persona DESC LIMIT 1");
$personadatos1 = mysql_fetch_array($persona1);
$idcargo = $personadatos1["Id_Cargo"];
$idjunta = $personadatos1["Id_Junta"];
//consultar datos del cargo
$cargo1 =mysql_query("SELECT * FROM cargo  WHERE Id_Cargo = '$idcargo'");
$cargoa = mysql_fetch_array($cargo1);
$cargo = $cargoa["Cargo"];
//consultar datos de la junta a la que pertenece 
$junta1 =mysql_query("SELECT * FROM junta  WHERE Id_Junta = '$idjunta'");
$juntaa = mysql_fetch_array($junta1);
$nombrejunta = $juntaa["Razon"];
$idmunicipio = 	$juntaa["Id_Municipio"];
//consultar datos de municipio de la junta
$muni1 =mysql_query("SELECT * FROM municipio  WHERE Id_Municipio = '$idmunicipio'");
$munia = mysql_fetch_array($muni1);
$municipio = $munia["Municipio"];
?>
<script type="text/javascript">
/*alerta de que un documento se encuenta tregistrado en un periodo menor a 3 meses*/
function RegistroRepetido() {
alert('<?php echo  "documento registrado en la junta "; echo $nombrejunta; echo " del municipio de " ; echo $municipio  ; echo " ,con el cargo de  "; echo $cargo ; echo " verifique la informacion con la junta mencionada " ; ?>');
document.location=('datosjunta.php');
}
</script>
<?php
echo "<script type='text/javascript'>RegistroRepetido();</script>";
}
?>