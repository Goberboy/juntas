<?php
session_start();
//Connect to database
require_once('../Connections/junta.php');
$idjunta = $_SESSION['idjunta'];
//$idjunta = 9;
$fechaactual = date("Y/m/d");
$hora = date("H:i:s");
if (isset($_GET['cuenta'])) {
	 $factura1 = $_GET['cuenta'];
	}
	else {
		$factura1 = "";
		}
$autoincremental = $factura1;		
//datos de la junta 
$consultajunta=mysql_query("SELECT * FROM junta WHERE Id_Junta = '$idjunta'");
$consultajunta1 = mysql_fetch_array($consultajunta);
$razon = 				$consultajunta1['Razon'];
$fechacreacion = 		$consultajunta1['F_Creacion'];
$personeriajuridica = 	$consultajunta1['N_Personeria_Juridica'];
$idmunicipio = 			$consultajunta1['Id_Municipio'];
$idtipojunta = 			$consultajunta1['Id_Tipo_Junta'];
$idinstitucion = 		$consultajunta1['Id_Institucion'];
$idreconocida = 		$consultajunta1['Id_Reconocida'];
// datos del municipio de la junta 
$consultamunicipio=mysql_query("SELECT * FROM municipio WHERE Id_Municipio = '$idmunicipio'");
$consultamunicipio1 = mysql_fetch_array($consultamunicipio);
$municipio = 			$consultamunicipio1['Municipio'];
//datos del tipo de junta de la junta
$consultatipojunta=mysql_query("SELECT * FROM tipo_junta WHERE Id_Tipo_Junta = '$idtipojunta'");
$consultatipojunta1 = mysql_fetch_array($consultatipojunta);
$tipojunta = 			$consultatipojunta1['T_Junta'];
//datos de la institucion de la junta
$consultainstitucion=mysql_query("SELECT * FROM institucion WHERE Id_Institucion = '$idinstitucion'");
$consultainstitucion1 = mysql_fetch_array($consultainstitucion);
$institucion = 			$consultainstitucion1['Nom_Institucion'];
//datos de la reconocida de la junta
$consultareconocida=mysql_query("SELECT * FROM reconocida WHERE Id_Reconocida = '$idreconocida'");
$consultareconocida1 = mysql_fetch_array($consultareconocida);
$reconocida = 			$consultareconocida1['Reconocida'];
//datos de la ultima asamblea de la junta
$consultaasamblea=mysql_query("SELECT * FROM asamblea WHERE Id_junta = '$idjunta' ORDER BY Id_Asamblea DESC LIMIT 1");
$consultaasamblea1 = mysql_fetch_array($consultaasamblea);
$fechaasamblea = 		$consultaasamblea1['F_Asamblea'];
$fechainicioperiodo = 	$consultaasamblea1['F_I_Periodo'];
$fechafinperiodo = 		$consultaasamblea1['F_F_Periodo'];

// datos mandatario
$mandatario1 =mysql_query("SELECT * FROM mandatario ORDER BY Id_Mandatario DESC LIMIT 1");
$mandatario = mysql_fetch_array($mandatario1);
$nombre_mandatario = 			$mandatario['Nombre_Mandatario'];
$cargo_mandatario= 				$mandatario['Cargo_Mandatario'];
$firmamandatario = 				$mandatario['Imagen'];

require('../necesarios/fpdf.php');
class PDF extends FPDF
{
var $B;
var $I;
var $U;
var $HREF;

function PDF($orientation='P', $unit='mm', $size='letter')
{
    // Llama al constructor de la clase padre
    $this->FPDF($orientation,$unit,$size);
    // Iniciación de variables
    $this->B = 0;
    $this->I = 0;
    $this->U = 0;
    $this->HREF = '';
}

function WriteHTML($html)
{
    // Intérprete de HTML
    $html = str_replace("\n",' ',$html);
    $a = preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
    foreach($a as $i=>$e)
    {
        if($i%2==0)
        {
            // Text
            if($this->HREF)
                $this->PutLink($this->HREF,$e);
            else
                $this->Write(5,$e);
        }
        else
        {
            // Etiqueta
            if($e[0]=='/')
                $this->CloseTag(strtoupper(substr($e,1)));
            else
            {
                // Extraer atributos
                $a2 = explode(' ',$e);
                $tag = strtoupper(array_shift($a2));
                $attr = array();
                foreach($a2 as $v)
                {
                    if(preg_match('/([^=]*)=["\']?([^"\']*)/',$v,$a3))
                        $attr[strtoupper($a3[1])] = $a3[2];
                }
                $this->OpenTag($tag,$attr);
            }
        }
    }
}

function OpenTag($tag, $attr)
{
    // Etiqueta de apertura
    if($tag=='B' || $tag=='I' || $tag=='U')
        $this->SetStyle($tag,true);
    if($tag=='A')
        $this->HREF = $attr['HREF'];
    if($tag=='BR')
        $this->Ln(5);
}

function CloseTag($tag)
{
    // Etiqueta de cierre
    if($tag=='B' || $tag=='I' || $tag=='U')
        $this->SetStyle($tag,false);
    if($tag=='A')
        $this->HREF = '';
}

function SetStyle($tag, $enable)
{
    // Modificar estilo y escoger la fuente correspondiente
    $this->$tag += ($enable ? 1 : -1);
    $style = '';
    foreach(array('B', 'I', 'U') as $s)
    {
        if($this->$s>0)
            $style .= $s;
    }
    $this->SetFont('',$style);
}

function PutLink($URL, $txt)
{
    // Escribir un hiper-enlace
    $this->SetTextColor(0,0,255);
    $this->SetStyle('U',true);
    $this->Write(5,$txt,$URL);
    $this->SetStyle('U',false);
    $this->SetTextColor(0);
}}
$mensaje1 = "El(A) Director(a) de Participación y Administración Local en  uso  de  sus facultades legales  y en especial las que le confiere la ley 52 de 1990, la ley 743 de junio de 2002, Decretos 2350 del 20 de agosto de 2003 y 890 de 2008, compilados en el Decreto 1066 del 2015  y  Decretos  Departamentales  1237 y 1238 del 1 de agosto  de 2006.";
$mensaje2 = "Que la $tipojunta $razon del municipio de $municipio, Departamento de Boyacá, cuenta con $reconocida No.$personeriajuridica de fecha $fechacreacion, expedida por $institucion.";
$mensaje3 = "ARTICULO PRIMERO: Inscribir a la $tipojunta $razon del municipio de $municipio,Departamento de Boyacá, para el periodo comprendido entre el $fechainicioperiodo y el $fechafinperiodo a los siguientes dignatarios:";
//directivos
$consulta1="SELECT * FROM persona, detalle_persona, cargo, comision WHERE detalle_persona.Id_Junta = '$idjunta' AND detalle_persona.Documento = persona.Documento AND detalle_persona.Id_Cargo = cargo.Id_Cargo AND detalle_persona.Id_Comision = comision.Id_Comision AND detalle_persona.Estado = 'Activo' AND detalle_persona.Id_Cargo in (1,3,5) ORDER BY detalle_persona.Id_Cargo ASC";
$r1=mysql_query($consulta1);
$i1=mysql_num_rows($r1);


$j = 'J';
	$pdf=new PDF();
	$pdf->AddPage();
	$pdf->SetFont('Arial','',10);
	$pdf->Image("../necesarios/inicio.png", 10 ,10 ,45 ,20 );
		$pdf->Ln(30);
	$pdf->Cell (0,0,  "SECRETARÍA DE PARTICIPACIÓN Y DEMOCRACIA",0,1,'C');
		$pdf->Ln(5);
	$pdf->Cell (0,0,  "DIRECCIÓN DE PARTICIPACIÓN Y ADMINISTRACIÓN LOCAL",0,0,'C');
		$pdf->Ln(5);
	$pdf->MultiCell(190, 4, utf8_decode($mensaje1) , 0,$j);
			$pdf->Ln(5);
	$pdf->Cell (0,0,  "CERTIFICA:",0,0,'C');
			$pdf->Ln(5);
	$pdf->MultiCell(190, 4, utf8_decode($mensaje2) , 0,$j);
			$pdf->Ln(5);
	$pdf->Cell (0,0,  "Que fueron inscritos como dignatarios de dicha organización:",0,0,'C');
//DIRECTIVOS
if ($i1>0){
		$pdf->Ln(5);
	//$pdf->Cell (0,0,  "DIRECTIVOS",0,0,'C');
		//$pdf->Ln(5);
	$pdf->Cell(35,7,"CARGO",1,0,'C');
	$pdf->Cell(90,7,"NOMBRE Y APELLIDO ",1,0,'C');
	//$pdf->Cell(50,7,'APELLIDO',1,0,'C');
	$pdf->Cell(30,7,'DOCUMENTO',1,0,'C');
	$pdf->Cell(35,7,'EXPEDIDO EN',1,0,'C');	
		$pdf->Ln();
while($registro1=mysql_fetch_row($r1)){
	$pdf->SetFont('Arial','',8);
	$pdf->Cell(35,7,utf8_decode($registro1[30]),1,0,'C');
	$pdf->Cell(90,7,"$registro1[3] $registro1[4]",1,0,'C');
	//$pdf->Cell(50,7,utf8_decode($registro1[1]),1,0,'C');
	$pdf->Cell(30,7,utf8_decode($registro1[0]),1,0,'C');
	$pdf->Cell(35,7,utf8_decode($registro1[2]),1,0,'C');
		$pdf->Ln();
	}	
}

//articulo segundo
		$pdf->Ln(5);
	$pdf->SetFont('Arial','',10);
	$pdf->Cell(0,0, "Que el periodo de los actuales dignatarios vence $fechafinperiodo",0,0,'L');
//pie de pagina 
		$pdf->Ln(7);
	$pdf->Cell (0,0,  "Esta constacia es valida por el termino de 6 (seis) meses.",0,0,'L');
			$pdf->Ln(7);
	$pdf->Cell (0,0,  "Se expide con el fin de adelantar tramites de la junta.",0,0,'L');
		$pdf->Ln(5);
	$pdf->Cell (0,0,  "Dada en tunja el dia: $fechaactual",0,0,'L');	

	//$pdf->Image("../images/firma.png", 75 ,210 ,50 ,30 );
		$pdf->Ln(1);			
	$pdf->Cell (0,0,$pdf->Image("../".$firmamandatario,70),0,0,'',false);
		$pdf -> Ln (-10);		
	$pdf -> Cell (0,0,  $nombre_mandatario,0,0,'C');
		$pdf -> Ln (4);
	$pdf -> Cell (0,0,  $cargo_mandatario,0,0,'C');
		$pdf -> Ln (10);
	$pdf->SetFont('Arial','',8);
	$pdf -> Cell (0,0,  "Realizó_________________",0,0,'L');
		$pdf -> Ln (3);
	$pdf -> Cell (0,0,  "Elaboro:________________",0,0,'L');
		$pdf -> Ln (3);
	$pdf -> Cell (0,0,  "Fecha: $fechaactual",0,0,'L');
		$pdf -> Ln (3);
	$pdf -> Cell (0,0,  "Hora: $hora",0,0,'L');
		$pdf -> Ln (3);
	$pdf -> Cell (0,0,  "GOBERNACIÓN DE BOYACÁ",0,0,'L');
$pdf->Output();	
//unset($_SESSION['cuenta']); 
exit;

?>

