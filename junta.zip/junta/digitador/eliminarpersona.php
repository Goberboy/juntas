<?php require_once('../Connections/junta.php'); ?>
<?php
session_start();
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $updateSQL = sprintf("UPDATE detalle_persona SET Estado=%s WHERE Documento=%s",
                       GetSQLValueString($_POST['Estado'], "text"),
                       GetSQLValueString($_POST['Documento'], "int"));

  mysql_select_db($database_junta, $junta);
  $Result1 = mysql_query($updateSQL, $junta) or die(mysql_error());

  $insertSQL = sprintf("INSERT INTO detalle_persona (Documento, N_Afiliacion, F_Afiliacion, Id_Cargo, Id_Junta, Id_Periodo, Id_Comision, Sub_Direccion, Estado, Password, Id_Tipo_Usuario, Id_Usuario, F_Creacion, H_Creacion, Ip_Creacion) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, SHA(%s), %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Documento'], "text"),
                       GetSQLValueString($_POST['N_Afiliacion'], "int"),
                       GetSQLValueString($_POST['F_Afiliacion'], "text"),
                       GetSQLValueString($_POST['Id_Cargo'], "int"),
                       GetSQLValueString($_POST['Id_Junta'], "int"),
                       GetSQLValueString($_POST['Id_Periodo'], "int"),
                       GetSQLValueString($_POST['Id_Comision'], "int"),
                       GetSQLValueString($_POST['Sub_Direccion'], "text"),
                       GetSQLValueString($_POST['Estado1'], "text"),
                       GetSQLValueString($_POST['Password'], "text"),
                       GetSQLValueString($_POST['Id_Tipo_Usuario'], "int"),
                       GetSQLValueString($_POST['Id_Usuario'], "text"),
                       GetSQLValueString($_POST['F_Creacion'], "text"),
                       GetSQLValueString($_POST['H_Creacion'], "text"),
                       GetSQLValueString($_POST['Ip_Creacion'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result1 = mysql_query($insertSQL, $junta) or die(mysql_error());
  
  $updateGoTo = "datosjunta.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}


$colname_persona = "-1";
if (isset($_GET['idp'])) {
  $colname_persona = $_GET['idp'];
}
mysql_select_db($database_junta, $junta);
$query_persona = sprintf("SELECT * FROM detalle_persona WHERE Documento = %s", GetSQLValueString($colname_persona, "text"));
$persona = mysql_query($query_persona, $junta) or die(mysql_error());
$row_persona = mysql_fetch_assoc($persona);
$totalRows_persona = mysql_num_rows($persona);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
 
      <td><input type="submit" value="Actualizar registro" /></td>
    </tr>
  </table>
  <input type="hidden" name="Estado" value="Inactivo" />
  <input type="hidden" name="Id_Detalle_Persona" value="<?php echo $row_persona['Documento']; ?>" />
  <input type="hidden" name="Documento" value="<?php echo $row_persona['Documento']; ?>" />
  <input type="hidden" name="N_Afiliacion" value="<?php echo $row_persona['N_Afiliacion']; ?>" />
  <input type="hidden" name="F_Afiliacion" value="<?php echo $row_persona['F_Afiliacion']; ?>" />
  <input type="hidden" name="Id_Cargo" value="16" />
  <input type="hidden" name="Id_Junta" value="<?php echo $row_persona['Id_Junta']; ?>" />
  <input type="hidden" name="Id_Periodo" value="<?php echo $row_persona['Id_Periodo']; ?>" />
  <input type="hidden" name="Id_Comision" value="<?php echo $row_persona['Id_Comision']; ?>" />
  <input type="hidden" name="Sub_Direccion" value="<?php echo $row_persona['Sub_Direccion']; ?>" />
  <input type="hidden" name="Estado1" value="Activo" />
  <input type="hidden" name="Password" value="consulta" />
  <input type="hidden" name="Id_Tipo_Usuario" value="4" />
  <input type="hidden" name="Id_Usuario" value="<?php echo $_SESSION['usuariojunta'];?>" />
  <input type="hidden" name="F_Creacion" value="<?php echo date("Y-m-d");?>" />
  <input type="hidden" name="H_Creacion" value="<?php echo date("H:i:s");?>" />
  <input type="hidden" name="Ip_Creacion" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>" />
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($persona);
?>
