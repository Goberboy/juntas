<?php require_once('../Connections/junta.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE persona SET  Expedido=%s, Nombre_P=%s, Apellido=%s, Edad=%s, F_Nacimiento=%s, Residencia=%s, Telefono=%s, Profesion=%s, Email=%s WHERE Documento=%s",
                       
                  
                       GetSQLValueString($_POST['Expedido'], "text"),
					   GetSQLValueString($_POST['Nombre_P'], "text"),
                       GetSQLValueString($_POST['Apellido'], "text"),
                       GetSQLValueString($_POST['Edad'], "int"),
                       GetSQLValueString($_POST['F_Nacimiento'], "text"),
                       GetSQLValueString($_POST['Residencia'], "text"),
                       GetSQLValueString($_POST['Telefono'], "text"),
                       GetSQLValueString($_POST['Profesion'], "text"),
                       GetSQLValueString($_POST['Email'], "text"),
                       GetSQLValueString($_POST['Documento'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result1 = mysql_query($updateSQL, $junta) or die(mysql_error());

  $updateGoTo = "datosjunta.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form2")) {

// datos para tabla detalle persona 
if ($_POST['Id_Cargo'] == 4){$password = $documento; $tipousuario = 3;}else { $password = "consulta";$tipousuario = 4;  }	
  $updateSQL = sprintf("UPDATE detalle_persona SET Documento=%s, N_Afiliacion=%s, F_Afiliacion=%s, Id_Cargo=%s, Id_Cargo2=%s, Id_Comision=%s, Sub_Direccion=%s, Password=SHA('$password'), Id_Tipo_Usuario='$tipousuario' WHERE Id_Detalle_Persona=%s",
                       GetSQLValueString($_POST['Documento'], "text"),
                       GetSQLValueString($_POST['N_Afiliacion'], "int"),
                       GetSQLValueString($_POST['F_Afiliacion'], "text"),
                       GetSQLValueString($_POST['Id_Cargo'], "int"),
					   GetSQLValueString($_POST['Id_Cargo2'], "int"),
                       GetSQLValueString($_POST['Id_Comision'], "int"),
                       GetSQLValueString($_POST['Sub_Direccion'], "text"),
                       GetSQLValueString($_POST['Id_Detalle_Persona'], "int"));

  mysql_select_db($database_junta, $junta);
  $Result1 = mysql_query($updateSQL, $junta) or die(mysql_error());

  $updateGoTo = "datosjunta.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}


$colname_persona = "-1";
if (isset($_GET['idp'])) {
  $colname_persona = $_GET['idp'];
}
mysql_select_db($database_junta, $junta);
$query_persona = sprintf("SELECT * FROM persona WHERE Documento = %s", GetSQLValueString($colname_persona, "text"));
$persona = mysql_query($query_persona, $junta) or die(mysql_error());
$row_persona = mysql_fetch_assoc($persona);
$totalRows_persona = mysql_num_rows($persona);



mysql_select_db($database_junta, $junta);
$query_cargo = "SELECT * FROM cargo";
$cargo = mysql_query($query_cargo, $junta) or die(mysql_error());
$row_cargo = mysql_fetch_assoc($cargo);
$totalRows_cargo = mysql_num_rows($cargo);

mysql_select_db($database_junta, $junta);
$query_comision = "SELECT * FROM comision";
$comision = mysql_query($query_comision, $junta) or die(mysql_error());
$row_comision = mysql_fetch_assoc($comision);
$totalRows_comision = mysql_num_rows($comision);

$colname_personadetalle = "-1";
if (isset($_GET['idp'])) {
  $colname_personadetalle = $_GET['idp'];
}
mysql_select_db($database_junta, $junta);
$query_personadetalle = sprintf("SELECT * FROM detalle_persona WHERE Documento = %s  AND Estado in ('Activo','Cambio') ORDER BY Id_Detalle_Persona DESC", GetSQLValueString($colname_personadetalle, "text"));
$personadetalle = mysql_query($query_personadetalle, $junta) or die(mysql_error());
$row_personadetalle = mysql_fetch_assoc($personadetalle);
$totalRows_personadetalle = mysql_num_rows($personadetalle);

mysql_select_db($database_junta, $junta);
$query_cargo2 = "SELECT * FROM cargo";
$cargo2 = mysql_query($query_cargo2, $junta) or die(mysql_error());
$row_cargo2 = mysql_fetch_assoc($cargo2);
$totalRows_cargo2 = mysql_num_rows($cargo2);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<script type="text/javascript" src="../necesarios/tcal.js"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="../necesarios/tcal.css" />
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
</head>

<body>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Documento:</td>
      <td><?php echo $row_persona['Documento']; ?></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Expedida:</td>
      <td><label for="Expedido"></label>
     <input type="text" name="Expedido" value="<?php echo htmlentities($row_persona['Expedido'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Nombre:</td>
      <td><span id="sprytextfield1">
        <input type="text" name="Nombre_P" value="<?php echo htmlentities($row_persona['Nombre_P'], ENT_COMPAT, 'utf-8'); ?>" size="32" />
      <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Apellido:</td>
      <td><span id="sprytextfield2">
        <input type="text" name="Apellido" value="<?php echo htmlentities($row_persona['Apellido'], ENT_COMPAT, 'utf-8'); ?>" size="32" />
      <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Edad:</td>
      <td><span id="sprytextfield5">
      <input type="text" name="Edad" value="<?php echo htmlentities($row_persona['Edad'], ENT_COMPAT, 'utf-8'); ?>" size="32" />
<span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">F Nacimiento:</td>
      <td><span id="sprytextfield6">
      <input type="text" name="F_Nacimiento" value="<?php echo htmlentities($row_persona['F_Nacimiento'], ENT_COMPAT, 'utf-8'); ?>" size="28" class="tcal"/>
<span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Residencia:</td>
      <td><input type="text" name="Residencia" value="<?php echo htmlentities($row_persona['Residencia'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Telefono:</td>
      <td><input type="text" name="Telefono" value="<?php echo htmlentities($row_persona['Telefono'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Profesión:</td>
      <td><input type="text" name="Profesion" value="<?php echo htmlentities($row_persona['Profesion'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Email:</td>
      <td><span id="sprytextfield3">
      <input type="text" name="Email" value="<?php echo htmlentities($row_persona['Email'], ENT_COMPAT, 'utf-8'); ?>" size="32" />
<span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Actualizar registro" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="Documento" value="<?php echo $row_persona['Documento']; ?>" />
</form>
<p>&nbsp;</p>
<form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">N Afiliación:</td>
      <td><span id="sprytextfield4">
      <input type="text" name="N_Afiliacion" value="<?php echo htmlentities($row_personadetalle['N_Afiliacion'], ENT_COMPAT, 'utf-8'); ?>" size="32" />
<span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">F Afiliación:</td>
      <td><span id="sprytextfield7">
      <input type="text" name="F_Afiliacion" value="<?php echo htmlentities($row_personadetalle['F_Afiliacion'], ENT_COMPAT, 'utf-8'); ?>" size="28" class="tcal"/>
<span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Cargo:</td>
      <td><select name="Id_Cargo">
        <?php 
do {  
?>
        <option value="<?php echo $row_cargo['Id_Cargo']?>" <?php if (!(strcmp($row_cargo['Id_Cargo'], htmlentities($row_personadetalle['Id_Cargo'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>><?php echo $row_cargo['Cargo']?></option>
        <?php
} while ($row_cargo = mysql_fetch_assoc($cargo));
?>
      </select></td>
    </tr>
    <tr> </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Cargo 2</td>
      <td><label for="Id_Cargo2"></label>
        <select name="Id_Cargo2" id="Id_Cargo2">
          <option value="0" <?php if (!(strcmp(0, $row_personadetalle['Id_Cargo2']))) {echo "selected=\"selected\"";} ?>>Seleccione...</option>
          <?php
do {  
?>
          <option value="<?php echo $row_cargo2['Id_Cargo']?>"<?php if (!(strcmp($row_cargo2['Id_Cargo'], $row_personadetalle['Id_Cargo2']))) {echo "selected=\"selected\"";} ?>><?php echo $row_cargo2['Cargo']?></option>
          <?php
} while ($row_cargo2 = mysql_fetch_assoc($cargo2));
  $rows = mysql_num_rows($cargo2);
  if($rows > 0) {
      mysql_data_seek($cargo2, 0);
	  $row_cargo2 = mysql_fetch_assoc($cargo2);
  }
?>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Comisión:</td>
      <td><select name="Id_Comision">
        <?php 
do {  
?>
        <option value="<?php echo $row_comision['Id_Comision']?>" <?php if (!(strcmp($row_comision['Id_Comision'], htmlentities($row_personadetalle['Id_Comision'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>><?php echo $row_comision['Nombre_C']?></option>
        <?php
} while ($row_comision = mysql_fetch_assoc($comision));
?>
      </select></td>
    </tr>
    <tr> </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Sub Dirección:</td>
      <td><input type="text" name="Sub_Direccion" value="<?php echo htmlentities($row_personadetalle['Sub_Direccion'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Actualizar registro" /></td>
    </tr>
  </table>
  <input type="hidden" name="Id_Detalle_Persona" value="<?php echo $row_personadetalle['Id_Detalle_Persona']; ?>" />
  <input type="hidden" name="Documento" value="<?php echo htmlentities($row_personadetalle['Documento'], ENT_COMPAT, 'utf-8'); ?>" />
  <input type="hidden" name="MM_update" value="form2" />
  <input type="hidden" name="Id_Detalle_Persona" value="<?php echo $row_personadetalle['Id_Detalle_Persona']; ?>" />
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "none", {validateOn:["change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "none", {validateOn:["change"]});
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "email", {isRequired:false, useCharacterMasking:true, validateOn:["change"]});
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "integer", {isRequired:false, validateOn:["change"], useCharacterMasking:true});
var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5", "integer", {useCharacterMasking:true, isRequired:false, validateOn:["change"]});
var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6", "date", {format:"yyyy-mm-dd", useCharacterMasking:true, isRequired:false, validateOn:["change"]});
var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7", "date", {format:"yyyy-mm-dd", useCharacterMasking:true, isRequired:false, validateOn:["change"]});
</script>
</body>
</html>
<?php
mysql_free_result($persona);



mysql_free_result($cargo);

mysql_free_result($comision);

mysql_free_result($personadetalle);

mysql_free_result($cargo2);
?>
