<?php require_once('../Connections/junta.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_junta, $junta);
$query_consultatipojunta = "SELECT * FROM tipo_junta ORDER BY T_Junta ASC";
$consultatipojunta = mysql_query($query_consultatipojunta, $junta) or die(mysql_error());
$row_consultatipojunta = mysql_fetch_assoc($consultatipojunta);
$totalRows_consultatipojunta = mysql_num_rows($consultatipojunta);

mysql_select_db($database_junta, $junta);
$query_consultamunicipio = "SELECT * FROM municipio ORDER BY Municipio ASC";
$consultamunicipio = mysql_query($query_consultamunicipio, $junta) or die(mysql_error());
$row_consultamunicipio = mysql_fetch_assoc($consultamunicipio);
$totalRows_consultamunicipio = mysql_num_rows($consultamunicipio);

$tipo_consultajunta = "-1";
if (isset($_POST['tipojunta'])) {
  $tipo_consultajunta = $_POST['tipojunta'];
}
$muni_consultajunta = "-1";
if (isset($_POST['municipio'])) {
  $muni_consultajunta = $_POST['municipio'];
}
mysql_select_db($database_junta, $junta);
$query_consultajunta = sprintf("SELECT * FROM institucion, junta, reconocida WHERE junta.Id_Institucion = institucion.Id_Institucion AND junta.Id_Reconocida = reconocida.Id_Reconocida AND junta.Id_Municipio = %s AND junta.Id_Tipo_Junta = %s  ORDER BY junta.Razon ", GetSQLValueString($muni_consultajunta, "int"),GetSQLValueString($tipo_consultajunta, "int"));
$consultajunta = mysql_query($query_consultajunta, $junta) or die(mysql_error());
$row_consultajunta = mysql_fetch_assoc($consultajunta);
$totalRows_consultajunta = mysql_num_rows($consultajunta);


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <label for="tipojunta"></label>
  <table width="200" border="1" align="center">
    <tr>
      <td>Tipo Junta:</td>
      <td><select name="tipojunta" id="tipojunta">
        <option value="0">Seleccione...</option>
        <?php
do {  
?>
        <option value="<?php echo $row_consultatipojunta['Id_Tipo_Junta']?>"><?php echo $row_consultatipojunta['T_Junta']?></option>
        <?php
} while ($row_consultatipojunta = mysql_fetch_assoc($consultatipojunta));
  $rows = mysql_num_rows($consultatipojunta);
  if($rows > 0) {
      mysql_data_seek($consultatipojunta, 0);
	  $row_consultatipojunta = mysql_fetch_assoc($consultatipojunta);
  }
?>
      </select></td>
    </tr>
    <tr>
      <td>Municipio:</td>
      <td><label for="municipio"></label>
        <select name="municipio" id="municipio">
          <option value="0">Seleccione...</option>
          <?php
do {  
?>
          <option value="<?php echo $row_consultamunicipio['Id_Municipio']?>"><?php echo $row_consultamunicipio['Municipio']?></option>
          <?php
} while ($row_consultamunicipio = mysql_fetch_assoc($consultamunicipio));
  $rows = mysql_num_rows($consultamunicipio);
  if($rows > 0) {
      mysql_data_seek($consultamunicipio, 0);
	  $row_consultamunicipio = mysql_fetch_assoc($consultamunicipio);
  }
?>
      </select></td>
    </tr>
    <tr>
      <td colspan="2" align="center" ><input type="submit" name="button" id="button" value="Consultar" /></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <table border="1" align="center">
    <tr>
      <td>Razón</td>
      <td>Expedida</td>
      <td>Fecha Creación</td>
      <td>Reconocida</td>
      <td>Personeria N°</td>
    </tr>
    <?php do { ?>
      <tr>
        <td><a href="datosjunta.php?idj=<?php echo $row_consultajunta['Id_Junta']; ?>"><?php echo $row_consultajunta['Razon']; ?></a></td>
        <td><?php echo $row_consultajunta['Nom_Institucion']; ?></td>
        <td><?php echo $row_consultajunta['F_Creacion']; ?></td>
        <td><?php echo $row_consultajunta['Reconocida']; ?></td>
        <td><?php echo $row_consultajunta['N_Personeria_Juridica']; ?></td>
      </tr>
      <?php } while ($row_consultajunta = mysql_fetch_assoc($consultajunta)); ?>
  </table>
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($consultatipojunta);

mysql_free_result($consultamunicipio);

mysql_free_result($consultajunta);

?>
