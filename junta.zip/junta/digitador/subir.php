<?php require_once('../Connections/junta.php'); ?>
<?php
session_start();
$idjunta = $_SESSION['idjunta'];
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_junta, $junta);
$query_mandatario = "SELECT * FROM autoresolutorio WHERE Id_Junta = '$idjunta' ORDER BY Id_Autoresolutorio DESC";
$mandatario = mysql_query($query_mandatario, $junta) or die(mysql_error());
$row_mandatario = mysql_fetch_assoc($mandatario);
$totalRows_mandatario = mysql_num_rows($mandatario);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<form action="cargadocumento.php" method="post" enctype="multipart/form-data"> 

   	<p align="center">Cargue de Autoresolutorios y Certificados 	</p>
   	<p align="center">Solo documentos en pdf sin espacion ni caracteres especiales en el nombre del documento</p>
   	<table width="200" border="1" align="center">
   	  <tr>
   	    <td>Numero</td>
   	    <td><label for="Numero"></label>
        <input type="text" name="Numero" id="Numero" /></td>
      </tr>
   	  <tr>
   	    <td>Documento</td>
   	    <td><input name="documentoauto" id="documentoauto" type="file" /></td>
      </tr>
   	  <tr>
   	    <td colspan="2"><input type="submit" value="Enviar" /></td>
      </tr>
  </table>
  <p>&nbsp;</p>
  <table border="1" align="center">
    <tr>
      <td>Numero</td>
      <td>Fecha Ingreso</td>
    </tr>
    <?php do { ?>
      <tr>
        <td><a href="../descargarautoresolutorio.php?id=<?php echo $row_mandatario['Ruta']; ?>"><?php echo $row_mandatario['Ruta']; ?></a></td>
        <td><?php echo $row_mandatario['F_Ingreso']; ?></td>
      <?php } while ($row_mandatario = mysql_fetch_assoc($mandatario)); ?>
  </table>
<p><br>
</p> 
</form>
</body>
</html>
<?php
mysql_free_result($mandatario);
?>
</form>
<?	
//				  			  			  
//if($_POST['guardar']){
//$act = "INSERT INTO mandatario (Nombre_Mandatario, Cargo_Mandatario, Imagen) values (' ".$nombre.",".$cargo.",".$destino1."')";
//if(@mysql_query($act)){echo "La foto fue publicada con éxito";
//}}
//
//?>