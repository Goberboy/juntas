<?php require_once('../Connections/junta.php'); ?>
<?php
session_start();
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO asamblea (Id_Junta, Id_Periodo, F_Asamblea, F_I_Periodo, F_F_Periodo, Id_Usuario, F_Usuario) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Id_Junta'], "int"),
                       GetSQLValueString($_POST['Id_Periodo'], "int"),
                       GetSQLValueString($_POST['F_Asamblea'], "text"),
                       GetSQLValueString($_POST['F_I_Periodo'], "text"),
                       GetSQLValueString($_POST['F_F_Periodo'], "text"),
                       GetSQLValueString($_POST['Id_Usuario'], "text"),
                       GetSQLValueString($_POST['F_Usuario'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result1 = mysql_query($insertSQL, $junta) or die(mysql_error());

  $insertGoTo = "datosjunta.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form2")) {
  $updateSQL = sprintf("UPDATE junta SET N_Afiliados=%s WHERE Id_Junta=%s",
                       GetSQLValueString($_POST['N_Afiliados'], "int"),
                       GetSQLValueString($_POST['Id_Junta'], "int"));

  mysql_select_db($database_junta, $junta);
  $Result1 = mysql_query($updateSQL, $junta) or die(mysql_error());

  $updateGoTo = "datosjunta.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$idjun_datosjunta = "-1";
if (isset($_SESSION['idjunta'])) {
  $idjun_datosjunta = $_SESSION['idjunta'];
}
mysql_select_db($database_junta, $junta);
$query_datosjunta = sprintf("SELECT * FROM junta, municipio, tipo_junta, institucion, reconocida WHERE junta.Id_Junta = %s AND junta.Id_Municipio = municipio.Id_Municipio AND junta.Id_Tipo_Junta = tipo_junta.Id_Tipo_Junta AND junta.Id_Institucion = institucion.Id_Institucion AND junta.Id_Reconocida = reconocida.Id_Reconocida", GetSQLValueString($idjun_datosjunta, "int"));
$datosjunta = mysql_query($query_datosjunta, $junta) or die(mysql_error());
$row_datosjunta = mysql_fetch_assoc($datosjunta);
$totalRows_datosjunta = mysql_num_rows($datosjunta);

$colname_asamblea = "-1";
if (isset($_SESSION['idjunta'])) {
  $colname_asamblea = $_SESSION['idjunta'];
}
mysql_select_db($database_junta, $junta);
$query_asamblea = sprintf("SELECT * FROM asamblea WHERE Id_Junta = %s ORDER BY Id_Asamblea DESC LIMIT 1", GetSQLValueString($colname_asamblea, "int"));
$asamblea = mysql_query($query_asamblea, $junta) or die(mysql_error());
$row_asamblea = mysql_fetch_assoc($asamblea);
$totalRows_asamblea = mysql_num_rows($asamblea);

mysql_select_db($database_junta, $junta);
$query_periodo = "SELECT * FROM periodo ORDER BY Id_Periodo DESC";
$periodo = mysql_query($query_periodo, $junta) or die(mysql_error());
$row_periodo = mysql_fetch_assoc($periodo);
$totalRows_periodo = mysql_num_rows($periodo);

$colname_numerojunta = "-1";
if (isset($_SESSION['idjunta'])) {
  $colname_numerojunta = $_SESSION['idjunta'];
}
mysql_select_db($database_junta, $junta);
$query_numerojunta = sprintf("SELECT * FROM junta WHERE Id_Junta = %s", GetSQLValueString($colname_numerojunta, "int"));
$numerojunta = mysql_query($query_numerojunta, $junta) or die(mysql_error());
$row_numerojunta = mysql_fetch_assoc($numerojunta);
$totalRows_numerojunta = mysql_num_rows($numerojunta);

$colname_datosjunta = "-1";
if (isset($_SESSION['idjunta'])) {
  $colname_mandatario = $_SESSION['idjunta'];
}
mysql_select_db($database_junta, $junta);
$query_mandatario = sprintf("SELECT * FROM autoresolutorio WHERE Id_Junta = %s ORDER BY Id_Autoresolutorio DESC", GetSQLValueString($colname_mandatario, "int"));
$mandatario = mysql_query($query_mandatario, $junta) or die(mysql_error());
$row_mandatario = mysql_fetch_assoc($mandatario);
$totalRows_mandatario = mysql_num_rows($mandatario);;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="../necesarios/tcal.js"></script>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="../necesarios/tcal.css" />
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<title>Documento sin título</title>
</head>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Periodo:</td>
      <td><select name="Id_Periodo">
        <?php
do {  
?>
        <option value="<?php echo $row_periodo['Id_Periodo']?>"><?php echo $row_periodo['Periodo']?></option>
        <?php
} while ($row_periodo = mysql_fetch_assoc($periodo));
  $rows = mysql_num_rows($periodo);
  if($rows > 0) {
      mysql_data_seek($periodo, 0);
	  $row_periodo = mysql_fetch_assoc($periodo);
  }
?>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Fecha Asamblea:</td>
      <td><span id="sprytextfield1">
      <input type="text" name="F_Asamblea" value="2016-04-24" size="28" class="tcal"/>
      <span class="textfieldRequiredMsg">Se necesita un valor.</span><span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Fecha Inicio Periodo:</td>
      <td><span id="sprytextfield2">
      <input type="text" name="F_I_Periodo" value="2016-07-01" size="28" class="tcal"/>
      <span class="textfieldRequiredMsg">Se necesita un valor.</span><span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Fecha Fin Periodo:</td>
      <td><span id="sprytextfield3">
      <input type="text" name="F_F_Periodo" value="2020-06-30" size="28" class="tcal"/>
      <span class="textfieldRequiredMsg">Se necesita un valor.</span><span class="textfieldInvalidFormatMsg">Formato no válido.</span></span></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Insertar registro" /></td>
    </tr>
  </table>
  <input type="hidden" name="Id_Junta" value="<?php echo $_SESSION['idjunta']; ?>" />
  <input type="hidden" name="Id_Usuario" value="<?php echo $_SESSION['usuariojunta']; ?>" />
  <input type="hidden" name="F_Usuario" value="<?php echo date("Y-m-d"); ?>" />
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>
<form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Numero Afiliados:</td>
      <td><input type="text" name="N_Afiliados" value="<?php echo htmlentities($row_numerojunta['N_Afiliados'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Actualizar registro" /></td>
    </tr>
  </table>
  <input type="hidden" name="Id_Junta" value="<?php echo $row_numerojunta['Id_Junta']; ?>" />
  <input type="hidden" name="MM_update" value="form2" />
  <input type="hidden" name="Id_Junta" value="<?php echo $row_numerojunta['Id_Junta']; ?>" />
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="50%" border="1" align="center">
  <tr>
    <td align="justify"><?php echo $row_datosjunta['T_Junta']; ?> <?php echo $row_datosjunta['Razon']; ?> del municipio de <?php echo $row_datosjunta['Municipio']; ?>, Departamento de Boyacá, con <?php echo $row_datosjunta['Reconocida']; ?> No.<?php echo $row_datosjunta['N_Personeria_Juridica']; ?> de fecha <?php echo $row_datosjunta['F_Creacion']; ?>,  expedida por <?php echo $row_datosjunta['Nom_Institucion']; ?>, Realizó Asamblea  General  el  dia  <?php echo $row_asamblea['F_Asamblea']; ?> con el fin de elegir dignatarios para el periodo comprendido entre el <?php echo $row_asamblea['F_I_Periodo']; ?> y el <?php echo $row_asamblea['F_F_Periodo']; ?>.</td>
  </tr>
</table>
<p align="center">Autoresolutorio y certificado</p>
 <table border="1" align="center">
    <tr>
      <td>Dato</td>
      <td>Fecha Ingreso</td>
    </tr>
    <?php do { ?>
      <tr>
        <td><a href="../descargarautoresolutorio.php?id=<?php echo $row_mandatario['Ruta']; ?>"><?php echo $row_mandatario['Ruta']; ?></a></td>
        <td><?php echo $row_mandatario['F_Ingreso']; ?></td>
      <?php } while ($row_mandatario = mysql_fetch_assoc($mandatario)); ?>
</table>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "date", {format:"yyyy-mm-dd", useCharacterMasking:true, validateOn:["change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "date", {format:"yyyy-mm-dd", useCharacterMasking:true, validateOn:["change"]});
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "date", {format:"yyyy-mm-dd", useCharacterMasking:true, validateOn:["change"]});
</script>
</body>
</html>
<?php
mysql_free_result($datosjunta);

mysql_free_result($asamblea);

mysql_free_result($periodo);

mysql_free_result($numerojunta);


?>
