<?php require_once('../Connections/junta.php'); ?>
<?php
session_start();
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO junta (Id_Municipio, Id_Tipo_Junta, Id_Institucion, Id_Reconocida, Razon, Direccion, F_Creacion, N_Personeria_Juridica, Zona) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Id_Municipio'], "int"),
                       GetSQLValueString($_POST['Id_Tipo_Junta'], "int"),
                       GetSQLValueString($_POST['Id_Institucion'], "int"),
                       GetSQLValueString($_POST['Id_Reconocida'], "int"),
                       GetSQLValueString($_POST['Razon'], "text"),
                       GetSQLValueString($_POST['Direccion'], "text"),
                       GetSQLValueString($_POST['F_Creacion'], "text"),
                       GetSQLValueString($_POST['N_Personeria_Juridica'], "text"),
                       GetSQLValueString($_POST['Zona'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result1 = mysql_query($insertSQL, $junta) or die(mysql_error());
 //ultimo id para la tabla de grupo
$personeria = $_POST['N_Personeria_Juridica'];
$creacion = $_POST['F_Creacion'];
$rs = mysql_query("SELECT MAX(Id_Junta) AS id FROM junta WHERE N_Personeria_Juridica = '$personeria' AND  F_Creacion = '$creacion'");
if ($row = mysql_fetch_row($rs)) {
$idjunta = trim($row[0]);
$_SESSION['idjunta'] = $idjunta; }
  $insertSQL = sprintf("INSERT INTO asamblea (Id_Junta, Id_Periodo, F_Asamblea, F_I_Periodo, F_F_Periodo, Id_Usuario, F_Usuario) VALUES ('$idjunta', %s, %s, %s, %s, %s, %s)",
                       
                       GetSQLValueString($_POST['Id_Periodo'], "int"),
                       GetSQLValueString($_POST['F_Asamblea'], "text"),
                       GetSQLValueString($_POST['F_I_Periodo'], "text"),
                       GetSQLValueString($_POST['F_F_Periodo'], "text"),
                       GetSQLValueString($_POST['Id_Usuario'], "text"),
                       GetSQLValueString($_POST['F_Usuario'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result1 = mysql_query($insertSQL, $junta) or die(mysql_error());

  $insertGoTo = "datosjunta.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_junta, $junta);
$query_municipio = "SELECT * FROM municipio ORDER BY Municipio ASC";
$municipio = mysql_query($query_municipio, $junta) or die(mysql_error());
$row_municipio = mysql_fetch_assoc($municipio);
$totalRows_municipio = mysql_num_rows($municipio);

mysql_select_db($database_junta, $junta);
$query_institucion = "SELECT * FROM institucion ORDER BY Nom_Institucion ASC";
$institucion = mysql_query($query_institucion, $junta) or die(mysql_error());
$row_institucion = mysql_fetch_assoc($institucion);
$totalRows_institucion = mysql_num_rows($institucion);

mysql_select_db($database_junta, $junta);
$query_tipojunta = "SELECT * FROM tipo_junta ORDER BY T_Junta ASC";
$tipojunta = mysql_query($query_tipojunta, $junta) or die(mysql_error());
$row_tipojunta = mysql_fetch_assoc($tipojunta);
$totalRows_tipojunta = mysql_num_rows($tipojunta);

mysql_select_db($database_junta, $junta);
$query_reconocida = "SELECT * FROM reconocida ORDER BY Reconocida ASC";
$reconocida = mysql_query($query_reconocida, $junta) or die(mysql_error());
$row_reconocida = mysql_fetch_assoc($reconocida);
$totalRows_reconocida = mysql_num_rows($reconocida);

mysql_select_db($database_junta, $junta);
$query_periodo = "SELECT * FROM periodo ORDER BY Id_Periodo ASC";
$periodo = mysql_query($query_periodo, $junta) or die(mysql_error());
$row_periodo = mysql_fetch_assoc($periodo);
$totalRows_periodo = mysql_num_rows($periodo);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../necesarios/tcal.css" />
<script type="text/javascript" src="../necesarios/tcal.js"></script>
<title>Documento sin título</title>
</head>

<body>

<p>&nbsp;</p>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td colspan="2" align="center" nowrap="nowrap">Datos Junta</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Municipio:</td>
      <td><select name="Id_Municipio">
        <option value="0">Seleccione...</option>
        <?php
do {  
?>
        <option value="<?php echo $row_municipio['Id_Municipio']?>"><?php echo $row_municipio['Municipio']?></option>
        <?php
} while ($row_municipio = mysql_fetch_assoc($municipio));
  $rows = mysql_num_rows($municipio);
  if($rows > 0) {
      mysql_data_seek($municipio, 0);
	  $row_municipio = mysql_fetch_assoc($municipio);
  }
?>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Tipo Junta:</td>
      <td><select name="Id_Tipo_Junta">
        <option value="0">Seleccione...</option>
        <?php
do {  
?>
        <option value="<?php echo $row_tipojunta['Id_Tipo_Junta']?>"><?php echo $row_tipojunta['T_Junta']?></option>
        <?php
} while ($row_tipojunta = mysql_fetch_assoc($tipojunta));
  $rows = mysql_num_rows($tipojunta);
  if($rows > 0) {
      mysql_data_seek($tipojunta, 0);
	  $row_tipojunta = mysql_fetch_assoc($tipojunta);
  }
?>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Institución:</td>
      <td><select name="Id_Institucion">
        <option value="0">Seleccione...</option>
        <?php
do {  
?>
        <option value="<?php echo $row_institucion['Id_Institucion']?>"><?php echo $row_institucion['Nom_Institucion']?></option>
        <?php
} while ($row_institucion = mysql_fetch_assoc($institucion));
  $rows = mysql_num_rows($institucion);
  if($rows > 0) {
      mysql_data_seek($institucion, 0);
	  $row_institucion = mysql_fetch_assoc($institucion);
  }
?>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Reconocida:</td>
      <td><select name="Id_Reconocida">
        <option value="0">Seleccione...</option>
        <?php
do {  
?>
        <option value="<?php echo $row_reconocida['Id_Reconocida']?>"><?php echo $row_reconocida['Reconocida']?></option>
        <?php
} while ($row_reconocida = mysql_fetch_assoc($reconocida));
  $rows = mysql_num_rows($reconocida);
  if($rows > 0) {
      mysql_data_seek($reconocida, 0);
	  $row_reconocida = mysql_fetch_assoc($reconocida);
  }
?>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Razón:</td>
      <td><input type="text" name="Razon" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Dirección(Lugar):</td>
      <td><input type="text" name="Direccion" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Fecha Creación:</td>
      <td><input type="text" name="F_Creacion" value="" size="28" class="tcal"/></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">N Personeria Juridica:</td>
      <td><input type="text" name="N_Personeria_Juridica" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Zona:</td>
      <td><select name="Zona">
        <option value="0" <?php if (!(strcmp(0, ""))) {echo "SELECTED";} ?>>Seleccione..</option>
        <option value="Urbana" <?php if (!(strcmp("Urbana", ""))) {echo "SELECTED";} ?>>Urbana</option>
        <option value="Rural" <?php if (!(strcmp("Rural", ""))) {echo "SELECTED";} ?>>Rural</option>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="center" nowrap="nowrap">Datos Asamblea</td>
    </tr>

  <p>&nbsp;</p>
  <p>
    <input type="hidden" name="MM_insert" value="form1" />
  </p>

    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Periodo:</td>
      <td><select name="Id_Periodo">
        <option value="0">Seleccione...</option>
        <?php
do {  
?>
        <option value="<?php echo $row_periodo['Id_Periodo']?>"><?php echo $row_periodo['Periodo']?></option>
        <?php
} while ($row_periodo = mysql_fetch_assoc($periodo));
  $rows = mysql_num_rows($periodo);
  if($rows > 0) {
      mysql_data_seek($periodo, 0);
	  $row_periodo = mysql_fetch_assoc($periodo);
  }
?>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Fecha Asamblea:</td>
      <td><input type="text" name="F_Asamblea" value="" size="28" class="tcal"/></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Fecha Inicio Periodo:</td>
      <td><input type="text" name="F_I_Periodo" value="" size="28" class="tcal"/></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Fecha Fin Periodo:</td>
      <td><input type="text" name="F_F_Periodo" value="" size="28" class="tcal"/></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Insertar registro" /></td>
    </tr>
  </table>
  <input type="hidden" name="Id_Junta" value="" />
  <input type="hidden" name="Id_Usuario" value="<?php echo $_SESSION['usuariojunta'];?>" />
  <input type="hidden" name="F_Usuario" value="<?php echo date("Y-m-d");?>" />
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($municipio);

mysql_free_result($institucion);

mysql_free_result($tipojunta);

mysql_free_result($reconocida);

mysql_free_result($periodo);
?>
