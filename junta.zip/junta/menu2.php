<style>
	.menu {
	width: 15%;
	height: 20px;
	float: left;
	padding: 10px;
	text-align: center;
	background: #fff;
	color: #C33;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 120%;	
	}
		.menu1 {
	width: 13%;
	height: 20px;
	float: left;
	padding: 10px;
	text-align: center;
	background: #fff;
	color: #FFF;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 120%;	
	}
	.menu:hover {
	background: #c33;
	color: #FFF;
	}
	#content {
		clear: both;
		background: #FFFFFF;
		padding: 0;
		overflow-y: scroll;
		overflow-X: scroll;
		width: 100%;
		height: 600px;
		border: 0;
		font-family: Verdana, Geneva, sans-serif;
		font-size: 120%;
	}



</style>
<script src="necesarios/jquery-1.11.3.js"></script>
<script>
	$(document).ready(function(e) {
		$('#menu1').on('click', function(){
			
			$('#content').attr('src', 'inicio.php');
		});
		$('#menu2').on('click', function(){
			$('#content').attr('src', 'digitador/crearjunta.php');
			
		});
		$('#menu3').on('click', function(){
			$('#content').attr('src', 'digitador/consultajunta.php');
			
		});
		$('#menu4').on('click', function(){		
			$('#content').attr('src', 'digitador/administracion.php');
			
		});
		$('#menu5').on('click', function(){		
			$('#content').attr('src', 'digitador/administracion.php');
			
		});
		$('#menu6').on('click', function(){		
			$('#content').attr('src', 'salir.php');
			
		});
		
		
	});
</script>    <div id="nav" align="center">
        <div id="" class="menu1"></div>
        <div id="menu1" class="menu">Inicio</div>
		<div id="menu2" class="menu">Crear Junta</div>
        <div id="menu3" class="menu">Consulta Junta</div>
        <div id="menu4" class="menu">Administración</div>
        <div id="" class="menu1"></div>
    </div>
	<div>
	<a href="http://201.245.195.2:83/juntasfinal/jun/consultaweb.php" target="_blank">Consulta V1</a>
	</div>
	