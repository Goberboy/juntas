<?php 
session_start();

$administrador = "index1.php";
$digitador = "index2.php";
$secretario = "index3.php";
//administrador
if ($_SESSION['MM_UserGroup'] ==1){header("Location: " . $administrador );}
//digitador
if ($_SESSION['MM_UserGroup'] ==2){header("Location: " . $digitador );}
//secretario
if ($_SESSION['MM_UserGroup'] ==3){header("Location: " . $secretario );}
?>