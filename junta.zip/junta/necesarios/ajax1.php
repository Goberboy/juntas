<?php
include("../Connections/junta.php");
$consulta = mysql_query("select * from junta where Id_Municipio=".$_GET['id']." ORDER BY Razon ASC");

echo "<select name='id_junta' id='id_junta'>";
while ($fila = mysql_fetch_array($consulta)) {
    echo "<option value='" . $fila[0] . "'>" . $fila[5] . "</option>";
}
echo "</select>";
?>