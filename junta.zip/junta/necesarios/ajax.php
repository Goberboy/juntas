<?php
include("../Connections/c_notificacion.php");
$consulta = mysql_query("select * from direccion where idd=".$_GET['id']." order by nombre ASC");

echo "<select name='id_direccion' id='id_direccion'>";
while ($fila = mysql_fetch_array($consulta)) {
    echo "<option value='" . $fila[1] . "'>" . $fila[2] . "</option>";
}
echo "</select>";
?>