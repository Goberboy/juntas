﻿<?php  
 function Conectar_Mysqli()
 {
  $_servidor="localhost";
  $_usuario="root";
  $_clave="GobBoy2016&";  
  $_basedatos="bdatos"; 
  $_conexion=mysqli_connect($_servidor,$_usuario,$_clave) or die("No se ha podido establecer la conexión con el servidor");    
  mysqli_select_db($_conexion,$_basedatos) or die("No se ha podido seleccionar la base de datos");
  return $_conexion;
 }   
 
 function ObtId()
 {
  $_conexion1 = Conectar_Mysqli();
  $_consulta1="Select max(id) as id from aportes";
  $rs=mysqli_query($_conexion1,$_consulta1);
  if ($row = mysqli_fetch_row($rs))
  {
   $_resul=trim($row[0]);
  }
  else
  {
   $_resul=trim("0");
  }
  mysqli_free_result($rs);
  mysqli_close($_conexion1);
  return $_resul;
 }
 
 function VUsuario($_login,$_password,&$_mensaje)
 {
  $_conexion1 = Conectar_Mysqli();
  $_consulta1="select * from usuarios where login='".$_login."'";
  $_resultado1=mysqli_query($_conexion1,$_consulta1);
  $_numreg1 = mysqli_num_rows($_resultado1);  
  if($_numreg1>0)
  {
   $_fila1=mysqli_fetch_object($_resultado1);
   if(sha1($_password)==$_fila1->password)
	$_resul=True;
   else
   {	   
	$_mensaje="Contraseña Incorrecta";
	$_resul=False;   
   }	
  }
  else
  {
   $_mensaje="El Usuario no se encuentra registrado";
   $_resul=False;
  }
  mysqli_free_result($_resultado1);
  mysqli_close($_conexion1);
  return $_resul;
 }  

function NCampo($_tabla,$_id)
 {
  $_conexion2 = Conectar_Mysqli();
  $_consulta2="select * from ".$_tabla." where id='".$_id."'";
  $_resultado2=mysqli_query($_conexion2,$_consulta2);
  $_numreg2 = mysqli_num_rows($_resultado2);  
  if($_numreg2>0)
  {
   $_fila2=mysqli_fetch_object($_resultado2);
   $_resul=$_fila2->nombre;	 
  }
  else
  {
   $_resul="";
  }  
  mysqli_free_result($_resultado2);
  mysqli_close($_conexion2);
  return $_resul;
 }   
 
 function NCampo2($_tabla,$_idd,$_id)
 {
  $_conexion2 = Conectar_Mysqli();
  $_consulta2="select * from ".$_tabla." where idd='".$_idd."' and id='".$_id."'";
  $_resultado2=mysqli_query($_conexion2,$_consulta2);
  $_numreg2 = mysqli_num_rows($_resultado2);  
  if($_numreg2>0)
  {
   $_fila2=mysqli_fetch_object($_resultado2);
   $_resul=$_fila2->nombre;	 
  }
  else
  {
   $_resul="";
  }  
  mysqli_free_result($_resultado2);
  mysqli_close($_conexion2);
  return $_resul;
 }      
 
 function Descarga($archivo)
 {
  $ruta = 'tu_aporte/'.$archivo;
  if (is_file($ruta))
  {
   header('Content-Type: application/force-download');
   header('Content-Disposition: attachment; filename='.$archivo);
   header('Content-Transfer-Encoding: binary');
   header('Content-Length: '.filesize($ruta));
   readfile($ruta);
  }	 
 } 
?>

