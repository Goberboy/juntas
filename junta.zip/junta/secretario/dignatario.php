<?php require_once('../Connections/junta.php'); ?>
<?php
session_start();
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$idjun_mandatariosjunta = "-1";
if (isset($_SESSION['idjunta'])) {
  $idjun_mandatariosjunta = $_SESSION['idjunta'];
}
mysql_select_db($database_junta, $junta);
$query_mandatariosjunta = sprintf("SELECT * FROM persona, detalle_persona, cargo, comision WHERE detalle_persona.Id_Junta = %s AND detalle_persona.Documento = persona.Documento AND detalle_persona.Id_Cargo = cargo.Id_Cargo AND detalle_persona.Id_Comision = comision.Id_Comision AND detalle_persona.Estado = 'Activo' AND detalle_persona.Id_Cargo NOT IN (16) ORDER BY detalle_persona.Id_Cargo", GetSQLValueString($idjun_mandatariosjunta, "int"));
$mandatariosjunta = mysql_query($query_mandatariosjunta, $junta) or die(mysql_error());
$row_mandatariosjunta = mysql_fetch_assoc($mandatariosjunta);
$totalRows_mandatariosjunta = mysql_num_rows($mandatariosjunta);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<table border="1" align="center">
  <tr>
    <td>Editar</td>
    <td>Cargo</td>
    <td>Comisión</td>
    <td>Dirección</td>
    <td>T Do</td>
    <td>Documento</td>
    <td>Expedido</td>
    <td>Nombre</td>
    <td>Apellido</td>
    <td>Genero</td>
    <td>Edad</td>
    <td>F Nacimiento</td>
    <td>Residencia</td>
    <td>Telefono</td>
    <td>Profesion</td>
    <td>Email</td>
    <td>Eliminar</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_mandatariosjunta['Documento']; ?></td>
      <td><?php echo $row_mandatariosjunta['Cargo']; ?></td>
      <td><?php echo $row_mandatariosjunta['Nombre_C']; ?></td>
      <td><?php echo $row_mandatariosjunta['Sub_Direccion']; ?></td>
      <td><?php echo $row_mandatariosjunta['Tipo_Documento']; ?></td>
      <td><?php echo $row_mandatariosjunta['Documento']; ?></td>
      <td><?php echo $row_mandatariosjunta['Expedido']; ?></td>
      <td><?php echo $row_mandatariosjunta['Nombre_P']; ?></td>
      <td><?php echo $row_mandatariosjunta['Apellido']; ?></td>
      <td><?php echo $row_mandatariosjunta['Genero']; ?></td>
      <td><?php echo $row_mandatariosjunta['Edad']; ?></td>
      <td><?php echo $row_mandatariosjunta['F_Nacimiento']; ?></td>
      <td><?php echo $row_mandatariosjunta['Residencia']; ?></td>
      <td><?php echo $row_mandatariosjunta['Telefono']; ?></td>
      <td><?php echo $row_mandatariosjunta['Profesion']; ?></td>
      <td><?php echo $row_mandatariosjunta['Email']; ?></td>
      <td><?php echo $row_mandatariosjunta['Documento']; ?></td>
    </tr>
    <?php } while ($row_mandatariosjunta = mysql_fetch_assoc($mandatariosjunta)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($mandatariosjunta);
?>
