<?php require_once('../Connections/junta.php'); ?>
<?php
session_start();
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$idjun_datosjunta = "-1";
if (isset($_SESSION['idjunta'])) {
  $idjun_datosjunta = $_SESSION['idjunta'];
}
mysql_select_db($database_junta, $junta);
$query_datosjunta = sprintf("SELECT * FROM junta, municipio, tipo_junta, institucion, reconocida WHERE junta.Id_Junta = %s AND junta.Id_Municipio = municipio.Id_Municipio AND junta.Id_Tipo_Junta = tipo_junta.Id_Tipo_Junta AND junta.Id_Institucion = institucion.Id_Institucion AND junta.Id_Reconocida = reconocida.Id_Reconocida", GetSQLValueString($idjun_datosjunta, "int"));
$datosjunta = mysql_query($query_datosjunta, $junta) or die(mysql_error());
$row_datosjunta = mysql_fetch_assoc($datosjunta);
$totalRows_datosjunta = mysql_num_rows($datosjunta);

$colname_asamblea = "-1";
if (isset($_SESSION['idjunta'])) {
  $colname_asamblea = $_SESSION['idjunta'];
}
mysql_select_db($database_junta, $junta);
$query_asamblea = sprintf("SELECT * FROM asamblea WHERE Id_Junta = %s ORDER BY Id_Asamblea DESC LIMIT 1", GetSQLValueString($colname_asamblea, "int"));
$asamblea = mysql_query($query_asamblea, $junta) or die(mysql_error());
$row_asamblea = mysql_fetch_assoc($asamblea);
$totalRows_asamblea = mysql_num_rows($asamblea);

$colname_datosjunta = "-1";
if (isset($_SESSION['idjunta'])) {
  $colname_mandatario = $_SESSION['idjunta'];
}
mysql_select_db($database_junta, $junta);
$query_mandatario = sprintf("SELECT * FROM autoresolutorio WHERE Id_Junta = %s ORDER BY Id_Autoresolutorio DESC", GetSQLValueString($colname_mandatario, "int"));
$mandatario = mysql_query($query_mandatario, $junta) or die(mysql_error());
$row_mandatario = mysql_fetch_assoc($mandatario);
$totalRows_mandatario = mysql_num_rows($mandatario);;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="50%" border="1" align="center">
  <tr>
    <td align="justify"><?php echo $row_datosjunta['T_Junta']; ?> <?php echo $row_datosjunta['Razon']; ?> del municipio de <?php echo $row_datosjunta['Municipio']; ?>, Departamento de Boyacá, con <?php echo $row_datosjunta['Reconocida']; ?> No.<?php echo $row_datosjunta['N_Personeria_Juridica']; ?> de fecha <?php echo $row_datosjunta['F_Creacion']; ?>,  expedida por <?php echo $row_datosjunta['Nom_Institucion']; ?>, Realizó Asamblea  General  el  dia  <?php echo $row_asamblea['F_Asamblea']; ?> con el fin de elegir dignatarios para el periodo comprendido entre el <?php echo $row_asamblea['F_I_Periodo']; ?> y el <?php echo $row_asamblea['F_F_Periodo']; ?>.</td>
  </tr>
</table>
<p align="center">Autoresolutorio y certificado</p>
 <table border="1" align="center">
    <tr>
      <td>Dato</td>
      <td>Fecha Ingreso</td>
    </tr>
    <?php do { ?>
      <tr>
        <td><a href="../descargarautoresolutorio.php?id=<?php echo $row_mandatario['Ruta']; ?>"><?php echo $row_mandatario['Ruta']; ?></a></td>
        <td><?php echo $row_mandatario['F_Ingreso']; ?></td>
      <?php } while ($row_mandatario = mysql_fetch_assoc($mandatario)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($datosjunta);

mysql_free_result($asamblea);


?>
