<?php require_once('../Connections/junta.php'); ?>
<script type="text/javascript">
/*alerta de que un documento se encuenta tregistrado en un periodo menor a 3 meses*/
function RegistroRepetido() {
alert('<?php echo  "USUARIO INGRESADO CORRECTAMENTE";?>');
document.location=('afiliado.php');
}
function Registroerror() {
alert('<?php echo  "USUARIO NO INGRESADO";?>');
document.location=('afiliado.php');
}
</script>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_GET['id'])) && ($_GET['id'] != "")) {
  $deleteSQL = sprintf("DELETE FROM detalle_persona WHERE Documento=%s",
                       GetSQLValueString($_GET['id'], "int"));

  mysql_select_db($database_junta, $junta);
  $Result1 = mysql_query($deleteSQL, $junta) or die(mysql_error());
  
  
    $deleteSQL3 = sprintf("DELETE FROM grupo WHERE Documento=%s",
                       GetSQLValueString($_GET['id'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result3 = mysql_query($deleteSQL3, $junta) or die(mysql_error());

    $deleteSQL2 = sprintf("DELETE FROM persona WHERE Documento=%s",
                       GetSQLValueString($_GET['id'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result2 = mysql_query($deleteSQL2, $junta) or die(mysql_error());
echo "<script type='text/javascript'>RegistroRepetido();</script>";
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
</body>
</html>