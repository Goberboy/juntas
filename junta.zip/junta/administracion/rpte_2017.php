<?php require_once('../Connections/junta.php'); ?>
<?php
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="consulta total de registros.xls"'); 
require_once("../Classes/PHPExcel.php");
require_once("../Classes/PHPExcel/Writer/Excel2007.php");
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_junta, $junta);
$query_todo = "SELECT * FROM persona, cargo, detalle_persona, grupo, comision, periodo, junta , municipio  WHERE detalle_persona.Documento = persona.Documento AND detalle_persona.Documento = grupo.Documento AND detalle_persona.Id_Cargo = cargo.Id_Cargo AND detalle_persona.Id_Periodo = periodo.Id_Periodo AND detalle_persona.Id_Comision = comision.Id_Comision  AND detalle_persona.Id_Junta = junta.Id_Junta AND junta.Id_Municipio = municipio.Id_Municipio AND detalle_persona.Estado IN ('Activo', 'Cambio')";
$todo = mysql_query($query_todo, $junta) or die(mysql_error());
$row_todo = mysql_fetch_assoc($todo);
$totalRows_todo = mysql_num_rows($todo);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<table border="1">
  <tr>
    <td>Documento</td>
    <td>Tipo Documento</td>
    <td>Expedido</td>
    <td>Nombre</td>
    <td>Apellido</td>
    <td>Genero</td>
    <td>Edad</td>
    <td>F Nacimiento</td>
    <td>Residencia</td>
    <td>Telefono</td>
    <td>Profesion</td>
    <td>Email</td>
    <td>Indigena</td>
    <td>Afro</td>
    <td>Con_Disca</td>
    <td>Desplazado</td>
    <td>Madre Gest</td>
    <td>Madre Lact</td>
    <td>Cabeza Hogar</td>
    <td>Adul_Mayor</td>
    <td>LGBTI</td>
    <td>Otra</td>
    <td>Cargo</td>
    <td>N Afiliacion</td>
    <td>F Afiliacion</td>
    <td>Sub_Direccion</td>
    <td>Nombre Comisión</td>
    <td>Periodo</td>
    <td>Municipio</td>
	<td>Zona</td>
    <td>Nombre Junta</td>
	<td>Fecha Personeria</td>
	<td>N. Personeria Juridica</td>
	<td>Expedida por</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_todo['Documento']; ?></td>
      <td><?php echo $row_todo['Tipo_Documento']; ?></td>
      <td><?php echo $row_todo['Expedido']; ?></td>
      <td><?php echo $row_todo['Nombre_P']; ?></td>
      <td><?php echo $row_todo['Apellido']; ?></td>
      <td><?php echo $row_todo['Genero']; ?></td>
      <td><?php echo $row_todo['Edad']; ?></td>
      <td><?php echo $row_todo['F_Nacimiento']; ?></td>
      <td><?php echo $row_todo['Residencia']; ?></td>
      <td><?php echo $row_todo['Telefono']; ?></td>
      <td><?php echo $row_todo['Profesion']; ?></td>
      <td><?php echo $row_todo['Email']; ?></td>
      
      <td><?php echo $row_todo['Indigena']; ?></td>
      <td><?php echo $row_todo['Afro']; ?></td>
      <td><?php echo $row_todo['Con_Disca']; ?></td>
      <td><?php echo $row_todo['Desplazado']; ?></td>
      <td><?php echo $row_todo['Madre_Gest']; ?></td>
      <td><?php echo $row_todo['Madre_Lact']; ?></td>
      <td><?php echo $row_todo['Cabeza_Hogar']; ?></td>
      <td><?php echo $row_todo['Adul_Mayor']; ?></td>
      <td><?php echo $row_todo['LGBTI']; ?></td>
      <td><?php echo $row_todo['Otra']; ?></td>
      <td><?php echo $row_todo['Cargo']; ?></td>
      <td><?php echo $row_todo['N_Afiliacion']; ?></td>
      <td><?php echo $row_todo['F_Afiliacion']; ?></td>
      <td><?php echo $row_todo['Sub_Direccion']; ?></td>
      <td><?php echo $row_todo['Nombre_C']; ?></td>
      <td><?php echo $row_todo['Periodo']; ?></td>
      <td><?php echo $row_todo['Municipio']; ?></td>
	  <td><?php echo $row_todo['Zona']; ?></td>
	  <td><?php echo $row_todo['Razon']; ?></td>
	  <td><?php echo $row_todo['F_Creacion']; ?></td>
	  <td><?php echo $row_todo['N_Personeria_Juridica']; ?></td>
	  <td><?php echo $row_todo['Id_Institucion']; ?></td>
	  <td><?php echo $row_todo['Nom_Institucion']; ?></td>
    </tr>
    <?php } while ($row_todo = mysql_fetch_assoc($todo)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($todo);

mysql_free_result($todo);
?>
