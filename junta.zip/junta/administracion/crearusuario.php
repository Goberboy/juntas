<?php require_once('../Connections/junta.php'); ?>
<?php
session_start();
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO persona (Tipo_Documento, Documento, Nombre_P, Apellido, Genero) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Tipo_Documento'], "text"),
                       GetSQLValueString($_POST['Documento'], "text"),
                       GetSQLValueString($_POST['Nombre_P'], "text"),
                       GetSQLValueString($_POST['Apellido'], "text"),
                       GetSQLValueString($_POST['Genero'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result1 = mysql_query($insertSQL, $junta) or die(mysql_error());
$contra =  $_POST['Documento'];
  $insertSQL2 = sprintf("INSERT INTO detalle_persona (Documento, Estado, Password, Id_Tipo_Usuario, Id_Usuario, F_Creacion, H_Creacion, Ip_Creacion) VALUES (%s, %s, SHA('$contra'), %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Documento'], "text"),
                       GetSQLValueString($_POST['Estado'], "text"),
                       GetSQLValueString($_POST['Id_Tipo_Usuario'], "int"),
                       GetSQLValueString($_POST['Id_Usuario'], "text"),
                       GetSQLValueString($_POST['F_Creacion'], "text"),
                       GetSQLValueString($_POST['H_Creacion'], "text"),
                       GetSQLValueString($_POST['Ip_Creacion'], "text"));

  mysql_select_db($database_junta, $junta);
  $Result2 = mysql_query($insertSQL2, $junta) or die(mysql_error());
}

mysql_select_db($database_junta, $junta);
$query_tipousuario = "SELECT * FROM tipo_usuario ORDER BY Nombre_U ASC";
$tipousuario = mysql_query($query_tipousuario, $junta) or die(mysql_error());
$row_tipousuario = mysql_fetch_assoc($tipousuario);
$totalRows_tipousuario = mysql_num_rows($tipousuario);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Tipo Documento:</td>
      <td><label for="Tipo_Documento"></label>
        <select name="Tipo_Documento" id="Tipo_Documento">
          <option value="C.C">C.C</option>
          <option value="T.I">T.I</option>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Documento:</td>
      <td><input type="text" name="Documento" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Nombre:</td>
      <td><input type="text" name="Nombre_P" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Apellido:</td>
      <td><input type="text" name="Apellido" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Genero:</td>
      <td><label for="Genero"></label>
        <select name="Genero" id="Genero">
          <option value="F">Femenino</option>
          <option value="M">Masculino</option>
      </select></td>
    </tr>

    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Tipo Usuario:</td>
      <td><select name="Id_Tipo_Usuario">
        <option value="0" >Seleccione...</option>
        <?php
do {  
?>
        <option value="<?php echo $row_tipousuario['id']?>"><?php echo $row_tipousuario['Nombre_U']?></option>
        <?php
} while ($row_tipousuario = mysql_fetch_assoc($tipousuario));
  $rows = mysql_num_rows($tipousuario);
  if($rows > 0) {
      mysql_data_seek($tipousuario, 0);
	  $row_tipousuario = mysql_fetch_assoc($tipousuario);
  }
?>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Insertar registro" /></td>
    </tr>
  </table>

  <input type="hidden" name="Estado" value="Cambio" />

  <input type="hidden" name="Id_Usuario" value="<?php echo $_SESSION['usuariojunta'];?>" />
  <input type="hidden" name="F_Creacion" value="<?php echo date("Y-m-d");?>" />
  <input type="hidden" name="H_Creacion" value="<?php echo date("H:i:s");?>" />
  <input type="hidden" name="Ip_Creacion" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>" />
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($tipousuario);
?>
