<?php require_once('../Connections/junta.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_persona = 10;
$pageNum_persona = 0;
if (isset($_GET['pageNum_persona'])) {
  $pageNum_persona = $_GET['pageNum_persona'];
}
$startRow_persona = $pageNum_persona * $maxRows_persona;

$colname_persona = "-1";
if (isset($_POST['documento'])) {
  $colname_persona = $_POST['documento'];
}
mysql_select_db($database_junta, $junta);
$query_persona = sprintf("SELECT * FROM persona WHERE Documento = %s", GetSQLValueString($colname_persona, "text"));
$query_limit_persona = sprintf("%s LIMIT %d, %d", $query_persona, $startRow_persona, $maxRows_persona);
$persona = mysql_query($query_limit_persona, $junta) or die(mysql_error());
$row_persona = mysql_fetch_assoc($persona);

if (isset($_GET['totalRows_persona'])) {
  $totalRows_persona = $_GET['totalRows_persona'];
} else {
  $all_persona = mysql_query($query_persona);
  $totalRows_persona = mysql_num_rows($all_persona);
}
$totalPages_persona = ceil($totalRows_persona/$maxRows_persona)-1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="200" border="1" align="center">
    <tr>
      <td>Documento:</td>
      <td><label for="documento"></label>
      <input type="text" name="documento" id="documento" /></td>
      <td><input type="submit" name="button" id="button" value="Consultar" /></td>
    </tr>
  </table>
  <p>&nbsp;</p>
 <?php 
 if (isset($_POST['documento'])&&($totalRows_persona!= "")) {
 ?> 
  <table border="1" align="center">
    <tr>
      <td>Documento</td>
      <td>Tipo Documento</td>
      <td>Expedido</td>
      <td>Nombre</td>
      <td>Apellido</td>
      <td>Genero</td>
      <td>Edad</td>
      <td>F Nacimiento</td>
      <td>Residencia</td>
      <td>Telefono</td>
      <td>Profesion</td>
      <td>Email</td>
    </tr>
    <?php do { ?>
      <tr>
        <td><a href="eliminarpersona.php?docu=<?php echo $row_persona['Documento']; ?>"><?php echo $row_persona['Documento']; ?></a></td>
        <td><?php echo $row_persona['Tipo_Documento']; ?></td>
        <td><?php echo $row_persona['Expedido']; ?></td>
        <td><?php echo $row_persona['Nombre_P']; ?></td>
        <td><?php echo $row_persona['Apellido']; ?></td>
        <td><?php echo $row_persona['Genero']; ?></td>
        <td><?php echo $row_persona['Edad']; ?></td>
        <td><?php echo $row_persona['F_Nacimiento']; ?></td>
        <td><?php echo $row_persona['Residencia']; ?></td>
        <td><?php echo $row_persona['Telefono']; ?></td>
        <td><?php echo $row_persona['Profesion']; ?></td>
        <td><?php echo $row_persona['Email']; ?></td>
      </tr>
      <?php } while ($row_persona = mysql_fetch_assoc($persona)); ?>
  </table>
  <?php } ?>
</form>
</body>
</html>
<?php
mysql_free_result($persona);
?>
