<?php
require_once '../Connections/junta.php';
session_start();
$nom=$_REQUEST["Nombre_Mandatario"];
$cargo = $_REQUEST["Cargo_Mandatario"];
//$direccion = $_SESSION['direccion'];

$nombrecompleto = $_FILES['Imagenfirma']['name'];
$ruta=$_FILES["Imagenfirma"]["tmp_name"];

$nombre = explode(".", $nombrecompleto); 
$extension = end($nombre); 
$foto= $_REQUEST["Nombre_Mandatario"];
$destino="../images/".$foto.".".$extension;
$destino1="images/".$foto.".".$extension;
copy($ruta,$destino);
mysql_query("insert into mandatario (Nombre_Mandatario,Cargo_Mandatario,Imagen,id_direccion) values('$nom','$cargo','$destino1', '1')");
header("Location: subir.php");
?>
