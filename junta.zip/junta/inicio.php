<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<p align="center">&nbsp;</p>
<!-- <table width="200" border="1">
  <tr>
    <td><a href="http://201.245.195.2:83/juntasfinal/jun/login.php" target="_blank">Login V1</a></td>
    <td><a href="http://201.245.195.2:83/juntasfinal/jun/consultaweb.php" target="_blank">Consulta V1</a></td>
  </tr>
</table> -->
<table width="512" border="0" align="center">
  <tr>
    <td><p align="center"><strong>Formatos Tarjetones</strong></p>
      <ul>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/formato-tarjeton-1.pdf" target="_blank">Formato Tarjetón Plancha 1</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/formato-tarjeton-2.pdf" target="_blank">Formato Tarjetón Plancha 2</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/formato-tarjeton-3.pdf" target="_blank">Formato Tarjetón Plancha 3</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/formato-tarjeton-4.pdf" target="_blank">Formato Tarjetón Plancha 4</a></li>
      </ul>
      <p align="center"><strong>Documentos Informativos</strong></p>
      <ul>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/ABC-Accion-Comunal.pdf" target="_blank">ABC de la Acción Comunal - Ministerio del Interior</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/ABC-Accion-Comunal-Cartilla-1.pdf" target="_blank">ABC Cartilla 1: Comunal para la participación</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/ABC-Accion-Comunal-Cartilla-2.pdf" target="_blank">ABC Cartilla 2: Manual de Elecciones Organización Comunal</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/ABC-Accion-Comunal-Cartilla-3.pdf" target="_blank">ABC Cartilla 3: Manual de Conciliación Comunal</a></li>
      </ul>
      <p align="center"><strong>Formatos para diligenciar</strong></p>
      <ul>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/acta-conformacion-veedurias.doc" target="_blank">Acta de conformación de veedurias ciudadanas</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/acta-eleccion-dignatarios-JAC.doc" target="_blank">Acta de elección de dignatarios Juntas de Acción Comunal (JAC)</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/acta-eleccion-dignatarios-JVC.doc" target="_blank">Acta de elección de dignatarios Juntas de Vivienda Comunitaria (JVC)</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/estatutos-vigentes-JAC.doc" target="_blank">Estatutos Junta de Acción Comunal (JAC)</a></li>
        <li>Estatutos Junta de Vivienda Comunitaria (JVC)</li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/formato-informacion-estadistica.xls" target="_blank">Registro de información estadística</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/formato-lista-JAC.xls" target="_blank">Formato elección por lista Juntas de Acción Comunal (JAC)</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/formato-lista-JVC.xls" target="_blank">Formato elección por lista Juntas de Vivienda Comunitaria (JVC)</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/formato-plancha-JAC.xls" target="_blank">Formato elección por plancha Juntas de Acción Comunal (JAC)</a></li>
        <li><a href="http://www.boyaca.gov.co/SecParticipacion/images/admlocal/infjuntas/formato-plancha-JVC.xls" target="_blank">Formato elección por plancha Juntas de Vivienda Comunitaria (JVC)</a></li>
    </ul></td>
  </tr>
</table>
</body>
</html>