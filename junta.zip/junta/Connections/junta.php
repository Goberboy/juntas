<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_junta = "localhost";
$database_junta = "junta2";
$username_junta = "junta";
$password_junta = "Gober2016%";
$junta = mysql_pconnect($hostname_junta, $username_junta, $password_junta) or trigger_error(mysql_error(),E_USER_ERROR); 

$conexion=mysql_connect($hostname_junta,$username_junta,$password_junta);
$db=mysql_select_db($database_junta);

date_default_timezone_set('America/Bogota'); 
?>