<?php require_once('Connections/junta.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_junta, $junta);
$query_usuario = "SELECT * FROM persona";
$usuario = mysql_query($query_usuario, $junta) or die(mysql_error());
$row_usuario = mysql_fetch_assoc($usuario);
$totalRows_usuario = mysql_num_rows($usuario);
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['usuario'])) {
  $loginUsername=$_POST['usuario'];
  $password=$_POST['password'];
  $MM_fldUserAuthorization = "Tipo";
  $MM_redirectLoginSuccess = "verificar.php";
  $MM_redirectLoginFailed = "desactivado.php";
  $desactivado = "desactivado.php";
  $cambio = "cambio.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_junta, $junta);
  	
  $LoginRS__query=sprintf("SELECT Id_Detalle_Persona, Documento, Password, Id_Tipo_Usuario, Estado, Id_Junta FROM detalle_persona WHERE Documento=%s AND Password=SHA(%s) AND (Estado = 'Activo' OR Estado = 'Cambio')  ORDER BY Id_Detalle_Persona DESC LIMIT 1",
  GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $junta) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
    
    $loginStrGroup  = mysql_result($LoginRS,0,'Id_Tipo_Usuario');
	$estado  = mysql_result($LoginRS,0,'Estado');
	$idjunta  = mysql_result($LoginRS,0,'Id_Junta');
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['usuariojunta'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;
	$_SESSION['idjunta'] = $idjunta;  
    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
	if ($estado == "Inactivo"){ header("Location: " . $desactivado );}
    if ($estado == "Activo"){ header("Location: " . $MM_redirectLoginSuccess );}
	if ($estado == "Cambio"){ header("Location: " . $cambio );}
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<form id="form1" name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
  <table width="200" border="1" align="center">
    <tr>
      <td>Usuario:</td>
      <td><label for="usuario"></label>
      <input type="text" name="usuario" id="usuario" /></td>
    </tr>
    <tr>
      <td>Contraseña:</td>
      <td><label for="password"></label>
      <input type="password" name="password" id="password" /></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><input type="submit" name="button" id="button" value="Enviar" /></td>
    </tr>
  </table>
</form>
</body>
</html>
<?php
mysql_free_result($usuario);
?>
